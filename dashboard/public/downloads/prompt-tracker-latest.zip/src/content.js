// Orchestrateur : score chaque prompt AVANT l'envoi. Sous le seuil, l'envoi est
// retenu (aucun crédit consommé) et la modale socratique s'affiche ; l'utilisateur
// choisit « améliorer » ou « envoyer quand même » : les deux choix sont tracés.
// Au-dessus du seuil, le prompt part normalement, sans latence ajoutée.

(() => {
  const DEFAULT_SETTINGS = { captureMode: "metadata", interceptEnabled: true, threshold: 40, theme: "light", postMirrorEnabled: true, profile: null };
  let settings = { ...DEFAULT_SETTINGS };
  // Config de l'organisation (branding, templates, seuil...) synchronisée par le
  // popup après login (étape 3). Prioritaire sur les réglages locaux.
  let orgConfig = null;
  let recentPromptTexts = []; // 3 derniers textes, en mémoire seulement
  let pendingToastEventId = null;
  // Fading : seuil effectif relevé par les séries de premiers jets réussis,
  // recalculé à chaque événement. La friction suit la compétence démontrée.
  let effectiveThreshold = null;
  // Dernier prompt parti (pour choisir la question du miroir d'après) :
  // catégorie, scores, et LANGUE DU PROMPT — la question réflexive doit
  // être posée dans la langue où l'utilisateur vient d'écrire.
  let lastPrompt = null;

  // Fenêtre pendant laquelle un événement envoyé attend ses mesures avant de
  // partir en sync. Un peu plus que le maxWaitMs du veilleur (120 s), pour
  // laisser un dépassement de délai écrire son verdict. Le verrou est une
  // DATE portée par l'événement, pas un minuteur : il survit à la fermeture de
  // l'onglet, à l'éviction du service worker et au mode hors ligne.
  const RESPONSE_HOLD_MS = 150000;

  // Fin de la dernière réponse observée, pour mesurer readMs : le délai entre
  // la fin d'une réponse et l'envoi du prompt suivant DANS LE MÊME FIL. C'est
  // le signal de sur-dépendance : a-t-il lu la réponse, ou enchaîné ?
  let lastResponseEnd = null; // { conv, at }

  // Au-delà, ce n'est plus de la lecture mais une reprise de session.
  const READ_MS_MAX = 30 * 60 * 1000;

  let adapterHealthy = null;

  // Bibliothèque de prompts publiée par l'organisation, tenue EN MÉMOIRE et
  // rafraîchie hors du chemin critique. La modale ne doit jamais attendre le
  // réseau — même contrat que les questions LLM : ce qui n'est pas là à
  // l'ouverture n'est simplement pas affiché ce tour-ci.
  let promptLibrary = null;

  function refreshLibrary() {
    if (!disclosureAccepted) return;
    if (!(orgConfig && orgConfig.libraryUrl)) {
      promptLibrary = null;
      return;
    }
    chrome.runtime.sendMessage({ type: "library-fetch" }, (res) => {
      if (chrome.runtime.lastError) return; // worker endormi : au prochain tour
      promptLibrary = (res && res.prompts) || null;
    });
  }

  // Repère visible dans l'UI du chat : l'extension est active (couleurs de l'org).
  function refreshBadge() {
    if (!disclosureAccepted) {
      CoachBadge.remove();
      return;
    }
    CoachBadge.render({
      branding: orgConfig && orgConfig.branding,
      healthy: adapterHealthy,
      threshold: currentThreshold(),
      interceptEnabled: effective("interceptEnabled"),
      // L'org impose le réglage : l'interrupteur de la pastille reste visible
      // mais inerte (le toggle local serait sans effet, cf. effective()).
      lockedByOrg: Boolean(orgConfig && orgConfig.interceptEnabled !== undefined && orgConfig.interceptEnabled !== null),
      // L'infobulle cite un seuil sur cent : c'est un score, donc soumis au
      // même réglage d'organisation que le reste du chiffré.
      showScore: effective("showScore") !== false,
    });
  }

  function currentThreshold() {
    return effectiveThreshold !== null ? effectiveThreshold : effective("threshold");
  }

  function recomputeThreshold(events) {
    effectiveThreshold = CoachScoring.adaptiveThreshold(events || [], effective("threshold"));
  }

  // Consentements de l'utilisateur (catégorie → bool), gérés par consent.html.
  let consents = {};

  // Divulgation bien visible (onboarding) : tant que l'utilisateur n'a pas
  // cliqué « J'accepte et j'active », l'extension est inerte : aucune capture,
  // même locale, aucun badge injecté dans la page.
  let disclosureAccepted = false;

  // Cadence « unité de tâche » : état par fil de conversation, hydraté en
  // mémoire (la décision d'interception doit rester synchrone à l'envoi).
  const pausedConvs = new Set(); // fils où l'utilisateur a dit « laisse-moi »
  const toastedConvs = new Set(); // fils ayant déjà reçu leur unique toast
  let pausePendingNewThread = false; // pause cliquée sur un fil pas encore créé (URL racine)
  let lowStreak = { conv: null, count: 0 }; // décrochages consécutifs dans le fil courant
  let pendingReentry = false; // la prochaine modale est une ré-entrée (sous-titre honnête)

  function persistConvSets() {
    chrome.storage.local.set({
      pausedConvs: [...pausedConvs].slice(-200),
      toastedConvs: [...toastedConvs].slice(-200),
    });
  }

  chrome.storage.local.get(["settings", "orgConfig", "consents", "events", "pausedConvs", "toastedConvs", "disclosure"], (data) => {
    settings = { ...DEFAULT_SETTINGS, ...(data.settings || {}) };
    orgConfig = data.orgConfig || null;
    consents = data.consents || {};
    disclosureAccepted = Boolean(data.disclosure && data.disclosure.accepted);
    for (const c of data.pausedConvs || []) pausedConvs.add(c);
    for (const c of data.toastedConvs || []) toastedConvs.add(c);
    recomputeThreshold(data.events);
    CoachTheme.set(settings.theme);
    refreshBadge();
    refreshLibrary();
  });
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.settings) settings = { ...DEFAULT_SETTINGS, ...changes.settings.newValue };
    if (changes.orgConfig) orgConfig = changes.orgConfig.newValue || null;
    if (changes.consents) consents = changes.consents.newValue || {};
    if (changes.disclosure) {
      disclosureAccepted = Boolean(changes.disclosure.newValue && changes.disclosure.newValue.accepted);
      refreshBadge();
    }
    if (changes.settings || changes.orgConfig) {
      chrome.storage.local.get("events", (data) => recomputeThreshold(data.events));
      CoachTheme.set(settings.theme);
      refreshBadge();
    }
    // L'organisation a publié, changé ou retiré sa bibliothèque.
    if (changes.orgConfig) refreshLibrary();
  });

  function effective(key) {
    if (orgConfig && orgConfig[key] !== undefined && orgConfig[key] !== null) return orgConfig[key];
    return settings[key];
  }

  // La catégorie est demandée par l'org ET consentie par l'utilisateur.
  function consented(cat) {
    const req = orgConfig && orgConfig.dataRequests && orgConfig.dataRequests[cat];
    return Boolean(req && req.requested && consents[cat]);
  }

  function appendEvent(event, callback) {
    chrome.storage.local.get("events", (data) => {
      const events = data.events || [];
      events.push(event);
      if (events.length > 5000) events.splice(0, events.length - 5000);
      recomputeThreshold(events);
      refreshBadge();
      chrome.storage.local.set({ events }, callback);
    });
  }

  /* ---------- Miroir d'après ---------- */

  // Trace de la réflexion post-réponse, dans un magasin séparé (les events de
  // prompts gardent leur schéma) : indicateurs seuls, texte si captureMode full.
  function appendPostEvent(postKey, answer, answered) {
    const event = {
      id: `${Date.now()}-${Math.floor(Math.random() * 1e6)}`,
      ts: new Date().toISOString(),
      site: CoachAdapter.site,
      conv: CoachAdapter.conversationKey(),
      postKey,
      category: (lastPrompt && lastPrompt.category) || "autre",
      answered,
      answerWords: CoachScoring.wordCount(answer || ""),
      // Texte gardé en local (c'est la réflexion de l'utilisateur, chez lui) ;
      // il ne part en sync que si post_reflection est demandé ET consenti.
      answer: answer || null,
      synced: false,
    };
    chrome.storage.local.get("postEvents", (data) => {
      const postEvents = data.postEvents || [];
      postEvents.push(event);
      if (postEvents.length > 1000) postEvents.splice(0, postEvents.length - 1000);
      chrome.storage.local.set({ postEvents });
    });
  }

  // Les conversations SANS id d'URL (chat éphémère, session déconnectée)
  // partagent toutes la clé racine : la marquer dans le storage supprimerait
  // le miroir d'après pour toujours sur ces chats. Pour elles, la règle
  // « une fois par conversation » se tient en mémoire (session de page).
  let postShownOnRoot = false;

  // Question réflexive de fin de génération (explain-back, vérification,
  // désaccord), au maximum UNE par conversation, jamais bloquante (P4, P10).
  function showPostMirror() {
    // La clé se lit à la FIN : une conversation neuve reçoit son id d'URL
    // pendant la génération (chatgpt.com/ devient chatgpt.com/c/<id>).
    const conv = CoachAdapter.conversationKey();
    if (isPaused(conv)) return; // « laisse-moi » vaut pour toutes les surfaces du fil
    const rootConv = CoachAdapter.isNewConversation();
    if (rootConv && postShownOnRoot) return;
    chrome.storage.local.get(["postConvs", "postCount"], (data) => {
      const convs = data.postConvs || [];
      if (!rootConv && convs.includes(conv)) return;
      const count = data.postCount || 0;
      const q = CoachScoring.postQuestion({
        category: lastPrompt && lastPrompt.category,
        scores: lastPrompt && lastPrompt.scores,
        lang: (lastPrompt && lastPrompt.lang) || CoachI18n.lang,
        count,
      });
      if (rootConv) {
        postShownOnRoot = true;
        chrome.storage.local.set({ postCount: count + 1 });
      } else {
        chrome.storage.local.set({ postConvs: [...convs.slice(-199), conv], postCount: count + 1 });
      }
      CoachMirror.showPost({
        question: q.question,
        branding: orgConfig && orgConfig.branding,
        onReply: (text) => appendPostEvent(q.key, text, true),
        onSkip: () => appendPostEvent(q.key, "", false),
      });
    });
  }

  /* ---------- Mesures post-réponse ---------- */

  // Traduit le contexte du veilleur en champs d'événement.
  function responseMetrics(ctx) {
    // Un onglet passé en arrière-plan gèle le rendu : les durées mesurées
    // deviennent « temps passé ailleurs », pas « durée de génération », et
    // rien ne le signale. On les jette plutôt que de les inventer. Les
    // TAILLES, elles, restent justes (le texte final est correct quand il
    // finit par s'afficher) : l'asymétrie est voulue.
    const timed = !ctx.hidden && ctx.firstTokenAt !== null;
    const plausible = (n, max) => (Number.isFinite(n) && n >= 0 && n <= max ? n : null);
    return {
      responsePending: false,
      responseOutcome: ctx.hidden ? "hidden" : ctx.reason,
      responseChars: ctx.chars,
      responseWords: ctx.words,
      model: ctx.model,
      modelCatalogVersion: ctx.model && typeof CoachModels !== "undefined" ? CoachModels.VERSION : null,
      turnIndex: ctx.turnIndex,
      latencyMs: timed ? plausible(ctx.firstTokenAt - ctx.sentAt, 600000) : null,
      responseMs: timed && ctx.lastActivityAt ? plausible(ctx.lastActivityAt - ctx.firstTokenAt, 3600000) : null,
    };
  }

  // Mesures : TOUJOURS actives. Ce sont des indicateurs du socle, au même
  // titre que les scores — elles ne dépendent d'aucun réglage optionnel.
  CoachAdapter.onResponse({
    onComplete(ctx) {
      // Seule une fin CONSTATÉE borne le temps de lecture : sur un dépassement
      // de délai, on ne sait pas quand la réponse s'est terminée.
      if (ctx.reason === "complete") {
        lastResponseEnd = { conv: CoachAdapter.conversationKey(), at: Date.now() };
      }
      if (ctx.eventId) patchEvent(ctx.eventId, responseMetrics(ctx));
    },
  });

  // Miroir d'après : optionnel. La porte de fonctionnalité vit ICI désormais,
  // et non plus sur l'armement du veilleur, qui sert les deux consommateurs.
  CoachAdapter.onResponse({
    onComplete(ctx) {
      if (!disclosureAccepted) return;
      if (!effective("postMirrorEnabled")) return;
      // Un dépassement de délai n'est pas une fin de réponse : ne jamais
      // interrompre une génération encore en cours avec une question.
      if (ctx.reason !== "complete") return;
      showPostMirror();
    },
  });

  // Après une injection : le veilleur n'est armé que si le prompt est
  // RÉELLEMENT parti. Sinon on relâche le verrou immédiatement, sans quoi la
  // ligne attendrait 150 s des mesures qui n'arriveront jamais.
  function armAfterSend(eventId, sent) {
    if (sent) CoachAdapter.armResponseWatch({ eventId, sentAt: Date.now() });
    else patchEvent(eventId, { responsePending: false, responseOutcome: "not_sent" });
  }

  // Mutation d'un événement DÉJÀ stocké. Seul motif légitime : une donnée qui
  // n'existe pas encore au moment de l'envoi (retour du miroir, mesures de
  // réponse). Le service worker écrit le même tableau : on relit au plus près
  // de l'écriture, et lui relit après son POST (cf. supabase.js).
  function patchEvent(eventId, patch) {
    chrome.storage.local.get("events", (data) => {
      const events = data.events || [];
      const ev = events.find((e) => e.id === eventId);
      if (!ev) return;
      Object.assign(ev, patch);
      chrome.storage.local.set({ events });
    });
  }

  function markFeedback(eventId, feedback) {
    patchEvent(eventId, { mirrorFeedback: feedback });
  }

  CoachMirror.onFeedback = () => pendingToastEventId && markFeedback(pendingToastEventId, "useful");
  CoachMirror.onPause = () => {
    pauseCurrentConv();
    if (pendingToastEventId) markFeedback(pendingToastEventId, "paused_thread");
  };
  CoachMirror.onClose = (reason) => {
    if (pendingToastEventId && reason === "dismissed") markFeedback(pendingToastEventId, "dismissed");
    pendingToastEventId = null;
  };

  function readMsForCurrentSend() {
    if (!lastResponseEnd) return null;
    // Sur un fil neuf, la clé de conversation est encore une racine partagée
    // par TOUS les nouveaux chats : impossible de rattacher honnêtement.
    if (CoachAdapter.isNewConversation()) return null;
    if (lastResponseEnd.conv !== CoachAdapter.conversationKey()) return null;
    const delta = Date.now() - lastResponseEnd.at;
    return delta >= 0 && delta <= READ_MS_MAX ? delta : null;
  }

  // Champs posés UNIQUEMENT sur les chemins d'envoi : un prompt annulé
  // n'attend aucune réponse et ne doit être retenu ni mesuré.
  function sendExtras() {
    return {
      responsePending: true,
      responseDeadline: Date.now() + RESPONSE_HOLD_MS,
      readMs: readMsForCurrentSend(),
    };
  }

  function buildEvent(text, scores, extra = {}) {
    const event = {
      id: `${Date.now()}-${Math.floor(Math.random() * 1e6)}`,
      ts: new Date().toISOString(),
      // Version du barème : indispensable pour recalibrer le scorer sans
      // polluer la courbe de progression (comparer à barème constant).
      // v3 (25/08/2026) : correction des frontières de mot, qui raisonnaient
      // en ASCII et rendaient invisibles les mots français à initiale
      // accentuée (« écris », « évalue », « étapes »), plus les verbes
      // d'action anglais manquants (« draft », « do »). C'est une correction
      // de PARITÉ entre langues, pas une recalibration : les scores montent
      // sur certains prompts français et anglais, jamais ils ne descendent.
      // Une courbe qui traverse cette date se compare à version constante.
      scoringVersion: 3,
      site: CoachAdapter.site,
      category: CoachScoring.categorize(text),
      words: CoachScoring.wordCount(text),
      promptChars: text.length,
      scores,
      // Mesures post-réponse : nulles à la création, remplies 5 à 60 s plus
      // tard par le veilleur via patchEvent. responsePending retient la ligne
      // côté sync — une ligne poussée ne peut JAMAIS être corrigée
      // (Prefer: resolution=ignore-duplicates).
      responsePending: false,
      responseDeadline: null,
      responseOutcome: null,
      model: null,
      modelCatalogVersion: null,
      responseChars: null,
      responseWords: null,
      latencyMs: null,
      responseMs: null,
      turnIndex: null,
      readMs: null,
      intercepted: false,
      outcome: null,
      scoreBefore: null,
      scoreAfter: null,
      mirrorShown: false,
      mirrorFeedback: null,
      rounds: 0,
      answersCount: 0,
      // Clé de conversation : locale toujours (c'est la machine de
      // l'utilisateur) ; elle ne part en sync que si consentie.
      conv: CoachAdapter.conversationKey(),
      synced: false,
      ...extra,
    };
    // Texte capturé localement si l'utilisateur le veut (réglage local) ou
    // s'il a consenti à le partager avec son org (il faut bien le capturer
    // pour pouvoir l'envoyer). La sync ne le transmet que si consenti.
    if (effective("captureMode") === "full" || consented("prompt_text")) event.text = text;
    return event;
  }

  function rememberText(text) {
    recentPromptTexts = [...recentPromptTexts.slice(-2), text];
  }

  // Pause d'un fil : le coach se tait sur toutes ses surfaces. Depuis la
  // modale d'un fil NEUF, l'URL est encore une racine : on mémorise la
  // demande et on l'applique dès que le fil a sa vraie clé.
  function pauseCurrentConv() {
    const conv = CoachAdapter.conversationKey();
    if (CoachAdapter.isNewConversation()) {
      pausePendingNewThread = true;
    } else {
      pausedConvs.add(conv);
      persistConvSets();
    }
  }

  function isPaused(conv) {
    if (pausedConvs.has(conv)) return true;
    if (pausePendingNewThread && !CoachAdapter.isNewConversation()) {
      // Le fil vient de recevoir son id : matérialiser la pause en attente.
      pausePendingNewThread = false;
      pausedConvs.add(conv);
      persistConvSets();
      return true;
    }
    return pausePendingNewThread;
  }

  CoachAdapter.init({
    // Décision synchrone, prise pendant l'événement d'envoi. Cadence « unité
    // de tâche » : la modale intercepte des OUVERTURES de fil ; dans un fil
    // lancé, elle ne revient que sur décrochage répété, jamais sur une suite.
    shouldIntercept(text) {
      if (!disclosureAccepted) return false;
      if (!effective("interceptEnabled")) return false;
      const scores = CoachScoring.score(text, recentPromptTexts);
      pendingReentry = false;

      // Fil neuf (URL racine : l'id n'existe pas encore) : règle d'ouverture.
      if (CoachAdapter.isNewConversation()) {
        return scores.total < currentThreshold();
      }

      // Fil existant.
      const conv = CoachAdapter.conversationKey();
      if (lowStreak.conv !== conv) lowStreak = { conv, count: 0 };
      if (isPaused(conv)) return false;
      // Une SUITE (raffinement, anaphore) n'est jamais un début de tâche.
      if (CoachScoring.isFollowUp(text, recentPromptTexts)) return false;
      // Tour substantiel : filet anti-décrochage (3 échecs nets consécutifs).
      if (CoachScoring.wordCount(text) >= 10) {
        if (scores.total < currentThreshold() - 15) lowStreak.count++;
        else lowStreak.count = 0;
        if (lowStreak.count >= 3) {
          lowStreak.count = 0;
          pendingReentry = true;
          return true;
        }
      }
      return false;
    },

    // Prompt retenu : rien n'est parti vers ChatGPT. Dialogue socratique
    // itératif : une question à la fois, une par axe faible, puis la main est
    // rendue (voir CoachScoring.coverage). L'utilisateur peut en demander une
    // de plus, et décide seul quand envoyer.
    onIntercept(text) {
      const scores = CoachScoring.score(text, recentPromptTexts);
      const templates = (orgConfig && orgConfig.templates) || {};
      // Langue du PROMPT, pas de l'interface : c'est elle qui choisit la
      // banque de questions, l'extraction de sujet et l'en-tête compilé.
      // La chrome de la modale (boutons, libellés) reste en langue d'interface :
      // ce sont deux choses différentes, et l'école le dit elle-même — la
      // langue de l'interface est un confort, celle du coaching décide de tout.
      const lang = CoachScoring.detectLang(text, CoachI18n.lang);
      const showScore = effective("showScore") !== false;

      // Question suivante : LLM sur mesure si l'org l'active (repli silencieux
      // sur la banque locale : l'itération n'attend jamais le réseau plus de 2 s).
      // Le prompt brut et le dialogue transitent par le serveur : cela exige
      // les consentements prompt_text ET socratic_dialogue (re-vérifié serveur).
      // llmActive est transmis à la modale : notice et badge disent à
      // l'utilisateur ce qui est généré par IA (transparence, retour terrain).
      const llmActive = Boolean(
        effective("llmEnabled") && consented("prompt_text") && consented("socratic_dialogue")
      );
      function ask(dialogueState) {
        // La relance (« autre question ») escalade l'exigence : un cran
        // au-dessus de la question écartée, localement comme côté LLM.
        const depth = Math.min(3, 1 + dialogueState.answers.length);
        const local = () =>
          CoachScoring.nextQuestion(
            {
              originalPrompt: text,
              scores,
              asked: dialogueState.asked,
              answeredCount: dialogueState.answers.length,
              reroll: Boolean(dialogueState.reroll),
              lastAxis: dialogueState.lastAxis || null,
              lastLevel: dialogueState.lastLevel || null,
              lang,
              profile: effective("profile"),
            },
            templates
          );
        if (!llmActive) return Promise.resolve(local());
        return new Promise((resolve) => {
          chrome.runtime.sendMessage(
            {
              type: "llm-question",
              prompt: text,
              dialogue: dialogueState.answers.map((a) => ({ question: a.question, answer: a.answer })),
              lang,
              intent: dialogueState.reroll ? "reroll" : "next",
              rejected: dialogueState.reroll && dialogueState.lastQuestion ? [dialogueState.lastQuestion] : [],
              askedQuestions: dialogueState.answers.slice(-3).map((a) => a.question),
              depth,
            },
            (res) => {
              if (!chrome.runtime.lastError && res && res.question) {
                resolve({
                  key: `llm-${dialogueState.asked.length}`,
                  axis: "llm",
                  label: CoachI18n.t("llmAxisLabel"),
                  question: res.question,
                  level: depth,
                  source: "llm",
                });
              } else {
                resolve(local());
              }
            }
          );
        });
      }

      const reentry = pendingReentry;
      pendingReentry = false;
      // Plan « si…, alors… » formulé à l'onboarding : rappelé tel quel pendant
      // 6 semaines (Gollwitzer ; Lally 2010 pour l'horizon), puis on s'efface.
      const intentionAge = Date.now() - Date.parse(settings.intentionSetAt || "");
      const intention =
        settings.intentionPlan && Number.isFinite(intentionAge) && intentionAge < 42 * 24 * 3600 * 1000
          ? settings.intentionPlan
          : null;
      CoachMirror.showModal({
        promptText: text,
        scoreBefore: scores.total,
        intention,
        branding: orgConfig && orgConfig.branding,
        // Ouverture de fil : promesse de tranquillité. Ré-entrée : honnêteté
        // sur la raison (3 décrochages), jamais de reproche.
        // L'organisation peut masquer tout ce qui est chiffré : la modale
        // reçoit le drapeau, et les sous-titres passent en variante sans note.
        showScore,
        // Bibliothèque de l'organisation, filtrée par la langue du prompt.
        library: promptLibrary,
        lang,
        subtitle: reentry
          ? CoachI18n.t(showScore ? "modalSubReentry" : "modalSubReentryNoScore", scores.total)
          : undefined,
        promise: !reentry,
        llmActive,
        onPause(m) {
          pauseCurrentConv();
          appendEvent(
            buildEvent(text, scores, {
              intercepted: true,
              outcome: "cancelled",
              scoreBefore: scores.total,
              mirrorShown: true,
              mirrorFeedback: "paused_thread",
              rounds: m.rounds,
              answersCount: m.answersCount,
              rerolls: m.rerolls,
            })
          );
        },
        // L'aperçu est re-scoré SANS l'échafaudage injecté par compilePrompt :
        // on mesure la réflexion de l'utilisateur, pas la structure du produit.
        rescore: (t) => CoachScoring.score(CoachScoring.stripScaffolding(t), recentPromptTexts),
        compile: (original, answers) => CoachScoring.compilePrompt(original, answers, lang),
        // Fin naturelle : la modale demande où en est la couverture des axes
        // faibles avant chaque question. Quand tout est couvert, elle rend la
        // main au lieu de recycler l'approfondissement (retour I-BE³ : le
        // recyclage se lit comme du remplissage dès le deuxième tour).
        coverage: (state) =>
          CoachScoring.coverage({ originalPrompt: text, scores, answers: state.answers, lang }),
        ask,
        onSend(finalText, m) {
          rememberText(finalText);
          const after = CoachScoring.score(finalText, recentPromptTexts);
          lastPrompt = { category: CoachScoring.categorize(finalText), scores: after, lang };
          // Lisibilité des modes (retour terrain) : dire in situ comment cet
          // envoi sera compté, au moment exact où la catégorie se décide.
          CoachMirror.flash(
            CoachI18n.t("toastSentImproved", (orgConfig && orgConfig.branding && orgConfig.branding.name) || CoachI18n.t("brandDefault")),
            orgConfig && orgConfig.branding && orgConfig.branding.color
          );
          const event = buildEvent(finalText, after, {
            intercepted: true,
            outcome: "improved",
            scoreBefore: scores.total,
            scoreAfter: after.total,
            mirrorShown: true,
            rounds: m.rounds,
            answersCount: m.answersCount,
            rerolls: m.rerolls,
            dialogue: m.answers && m.answers.length ? m.answers : null,
            ...sendExtras(),
          });
          appendEvent(event, () =>
            CoachAdapter.submitText(finalText).then((ok) => armAfterSend(event.id, ok))
          );
        },
        onSendAnyway(m) {
          rememberText(text);
          lastPrompt = { category: CoachScoring.categorize(text), scores, lang };
          CoachMirror.flash(
            CoachI18n.t("toastSentDirect"),
            orgConfig && orgConfig.branding && orgConfig.branding.color
          );
          const event = buildEvent(text, scores, {
            intercepted: true,
            outcome: "sent_anyway",
            scoreBefore: scores.total,
            scoreAfter: scores.total,
            mirrorShown: true,
            rounds: m.rounds,
            answersCount: m.answersCount,
            rerolls: m.rerolls,
            dialogue: m.answers && m.answers.length ? m.answers : null,
            ...sendExtras(),
          });
          appendEvent(event, () =>
            CoachAdapter.submitText(text).then((ok) => armAfterSend(event.id, ok))
          );
        },
        onCancel(m) {
          // Le prompt reste dans la zone de saisie, rien n'est envoyé.
          appendEvent(
            buildEvent(text, scores, {
              intercepted: true,
              outcome: "cancelled",
              scoreBefore: scores.total,
              mirrorShown: true,
              rounds: m.rounds,
              answersCount: m.answersCount,
              rerolls: m.rerolls,
            })
          );
        },
      });
    },

    // Prompt parti normalement (au-dessus du seuil ou interception désactivée).
    // Toast : au plus UN par fil, jamais sur un fil en pause, et jamais la
    // suggestion « trop court » sur une suite (usage normal du chat).
    onSubmit(text) {
      if (!disclosureAccepted) return;
      const scores = CoachScoring.score(text, recentPromptTexts);
      const lang = CoachScoring.detectLang(text, CoachI18n.lang);
      const conv = CoachAdapter.conversationKey();
      const isNew = CoachAdapter.isNewConversation();
      const followUp = CoachScoring.isFollowUp(text, recentPromptTexts);
      const toastAllowed =
        effective("interceptEnabled") && (isNew || (!isPaused(conv) && !toastedConvs.has(conv)));
      chrome.storage.local.get("events", (data) => {
        const suggestion = toastAllowed
          ? CoachScoring.socraticSuggestion(
              text,
              scores,
              (data.events || []).filter((e) => e.site === CoachAdapter.site),
              lang,
              followUp
            )
          : null;
        const event = buildEvent(text, scores, {
          outcome: "sent",
          mirrorShown: Boolean(suggestion),
          ...sendExtras(),
        });
        rememberText(text);
        lastPrompt = { category: event.category, scores, lang };
        appendEvent(event, () => {
          // Chemin non intercepté : le site a déjà envoyé le prompt lui-même.
          CoachAdapter.armResponseWatch({ eventId: event.id, sentAt: Date.now() });
          if (suggestion) {
            if (!isNew) {
              toastedConvs.add(conv);
              persistConvSets();
            }
            pendingToastEventId = event.id;
            CoachMirror.show(suggestion, orgConfig && orgConfig.branding && orgConfig.branding.color);
          }
        });
      });
    },
  });

  // Sonde de santé : si l'adaptateur ne trouve plus le composeur, le popup
  // alerte et le badge passe en avertissement dans l'UI du chat.
  setTimeout(() => {
    if (!disclosureAccepted) return; // inerte : pas même la sonde de santé
    adapterHealthy = CoachAdapter.healthy();
    const p = CoachAdapter.probe();
    chrome.storage.local.set({
      [`health_${CoachAdapter.site}`]: {
        healthy: adapterHealthy,
        checkedAt: new Date().toISOString(),
        // Sonde DOUCE, distincte de la panne dure : des sélecteurs de mesure
        // absents rendent les métriques nulles, le coaching continue.
        // null = aucun sélecteur déclaré pour ce site (Mistral, Grok).
        assistant: p.assistant,
        model: p.model,
      },
    });
    refreshBadge();
  }, 5000);
})();
