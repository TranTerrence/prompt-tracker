// Internationalisation FR/EN des surfaces de l'extension. La langue suit celle
// du navigateur (chrome.i18n), repli français. Les chaînes vivent ici (un seul
// catalogue) ; _locales/ ne porte que le nom et la description du manifest.

const CoachI18n = (() => {
  const MESSAGES = {
    fr: {
      brandDefault: "Prompt Tracker",
      // Badge
      badgeActive: (name, threshold) =>
        `${name} actif : au premier message d'un fil, un prompt sous ${threshold}/100 ouvre le dialogue de réflexion ; ensuite je te laisse la main. Clique pour replier.`,
      // Variante sans chiffre : l'organisation a choisi de ne pas montrer de
      // score. Le sens reste le même — dire quand le dialogue s'ouvre —, dit
      // en comportement plutôt qu'en note sur cent.
      badgeActiveNoScore: (name) =>
        `${name} actif : au premier message d'un fil, un prompt trop vague ouvre le dialogue de réflexion ; ensuite je te laisse la main. Clique pour replier.`,
      badgeWatch: (name) => `${name} actif : interception désactivée, tes prompts sont seulement analysés localement.`,
      badgeBroken: (name) => `${name}. Attention, l'UI du site a peut-être changé, la capture est à vérifier.`,
      badgeStandby: "(veille)",
      badgeToggleLabel: "Interception socratique",
      badgeToggleOn: "Interception active — clique pour mettre en veille",
      badgeToggleOff: "En veille — clique pour réactiver l'interception",
      badgeToggleLocked: "Réglage géré par ton organisation",
      // Toast
      toastTitle: "Miroir socratique",
      toastUseful: "👍 Utile",
      toastPause: "Pas dans ce fil",
      pauseConfirmed: "C'est noté, je te laisse dérouler. On se retrouve à la prochaine conversation.",
      // Miroir d'après (post-réponse)
      postTitle: "Miroir d'après",
      postPlaceholder: "En une phrase, avec tes mots…",
      postReply: "Répondre",
      postSkip: "Pas cette fois",
      postThanks: "Noté. Ta réflexion compte dans ta progression.",
      // Modale
      modalTitle: (name) => `${name} : réfléchissons ensemble`,
      modalSub: (score) =>
        `Prompt retenu avant envoi. Score initial ${score}/100. Réponds autant de fois que tu veux : c'est toi qui décides quand envoyer.`,
      modalSubNoScore:
        "Prompt retenu avant envoi. Réponds autant de fois que tu veux : c'est toi qui décides quand envoyer.",
      modalPromise: "Une fois la discussion lancée, je ne t'interromprai plus dans ce fil.",
      modalIntention: (plan) => `Ton plan : « ${plan} »`,
      modalSubReentry: (score) =>
        `Trois prompts d'affilée bien en dessous de ton niveau habituel (dernier : ${score}/100). On reprend deux minutes ? Tu peux toujours envoyer tel quel.`,
      modalSubReentryNoScore:
        "Trois prompts d'affilée bien en dessous de ton niveau habituel. On reprend deux minutes ? Tu peux toujours envoyer tel quel.",
      modalPause: "Laisse-moi sur ce fil",
      modalAnswerPlaceholder: "Ta réponse… (Entrée pour valider, Shift+Entrée pour un saut de ligne)",
      modalReply: "Répondre",
      modalSkip: "Passer cette question",
      modalSkipped: "(question passée)",
      modalOtherQuestion: "Autre question",
      modalOtherQuestionTitle: "Reformuler ou approfondir : une question différente, un cran plus exigeante.",
      modalBankExhausted: "Toutes les questions adaptées à ce prompt ont été posées. Réponds ou envoie quand tu es prêt.",
      // Fin naturelle du dialogue : une question par axe faible, puis la main
      // rendue. Le texte NOMME ce qui a été couvert — sans quoi « c'est fini »
      // ressemble à un abandon plutôt qu'à un travail terminé.
      modalCoverageDone: (axes) =>
        `Tu as couvert l'essentiel : ${axes}. À toi de décider quand envoyer.`,
      modalCoverageDoneShort: "Tu as posé ta réflexion. À toi de décider quand envoyer.",
      modalOneMore: "Poser une question de plus",
      // Bibliothèque de prompts publiée par l'organisation.
      libraryHead: (n) => `Partir d'un prompt qui a fonctionné (${n})`,
      libraryNote:
        "Publiés par ton école. Cliquer en charge un dans l'aperçu ; « recompiler depuis le dialogue » revient en arrière.",
      libraryOfficial: "Équipe pédagogique",
      libraryPeer: "Partagé par un étudiant",
      libraryCopies: (n) => `${n} reprises`,
      libraryHelpful: (n) => `${n} 👍`,
      // Popup : activation de la permission d'hôte, facultative.
      libraryOffer: (name) => `${name} propose une bibliothèque de prompts.`,
      libraryOfferHint:
        "L'extension lira cette page sans envoyer ton compte, tes prompts ni aucun identifiant. Tu peux refuser : rien d'autre ne change.",
      libraryEnable: "Activer la bibliothèque",
      libraryEnabled: "Bibliothèque activée.",
      libraryDenied: "Permission refusée. Tu peux réessayer quand tu veux.",
      // Popup : bibliothèque consultable (0.9.0). Copier, pas charger : il n'y
      // a pas d'aperçu ici, le prompt part dans le presse-papiers.
      libraryPanelHead: (n) => `Bibliothèque de prompts (${n})`,
      libraryPanelNote:
        "Publiés par ton école. Cliquer copie le prompt — colle-le dans ton chat et adapte-le.",
      librarySearch: "Rechercher…",
      libraryCopied: "Copié !",
      libraryCopyFailed: "Impossible de copier.",
      libraryLoading: "Chargement de la bibliothèque…",
      libraryEmptyPanel: "Aucun prompt publié pour le moment.",
      libraryNoMatch: "Aucun prompt ne correspond.",
      modalLlmBadge: "Question générée par IA",
      modalLlmNotice: "Questions sur mesure par IA : ton prompt et tes réponses transitent par le serveur (selon tes consentements), sans être stockés. En cas de lenteur, repli automatique sur la banque locale.",
      llmAxisLabel: "Ma réflexion",
      modalPreviewHead: "Prompt qui sera envoyé : score",
      modalPreviewHeadNoScore: "Prompt qui sera envoyé",
      rubClarte: "Clarté",
      rubContexte: "Contexte",
      rubCritique: "Esprit critique",
      modalRecompile: "recompiler depuis le dialogue",
      modalSend: "🚀 Envoyer au chat (avec ma réflexion)",
      modalSendAnyway: "Envoyer ma demande initiale telle quelle",
      modalCancelTitle: "Annuler (rien ne part, ton texte reste dans la zone de saisie)",
      // Compilation
      compileHeader: "Ma réflexion préalable :",
      // Popup
      popupTagline: "Le garde-fou de ton prompting",
      popupPrompts: "prompts",
      popupAvgScore: "premiers jets",
      popupTrend: "progression 7 j",
      popupMirror: "série de jours",
      popupStreakTitle: (n) => (n >= 2 ? `${n} jours d'affilée de premiers jets au niveau. C'est TA progression, sans coaching.` : "Jours consécutifs où tes premiers jets (avant tout coaching) atteignent le seuil."),
      popupStreakFreeze: (n) => (n === 1 ? "1 gel en réserve : un jour raté ne cassera pas ta série." : `${n} gels en réserve : gagnés par semaine complète réussie.`),
      popupEffThreshold: (base, eff) => (eff > base ? `Seuil effectif : ${eff} (la barre monte avec tes séries réussies)` : ""),
      popupRubrics: "Rubriques (moyenne /25)",
      popupCategories: "Catégories d'usage",
      popupSettings: "Réglages",
      popupThemeLabel: "Thème",
      themeLight: "Clair",
      themeDark: "Sombre",
      themeSystem: "Système",
      popupIntercept: "Interception socratique activée",
      popupThreshold: "Seuil d'interception :",
      popupFullText: "Conserver le texte des prompts (sinon : indicateurs seuls)",
      popupExport: "⬇️ Exporter CSV",
      popupReset: "Effacer les données",
      popupResetConfirm: "Effacer toutes les données locales ?",
      popupEmpty: "Aucun prompt capté pour l'instant. Utilise ChatGPT, Claude, Gemini, Mistral ou Grok, je te suis. 🙂",
      popupHealthBroken: (sites) => `⚠️ Capture peut-être cassée sur : ${sites} (UI modifiée)`,
      // Alerte douce : le coaching marche, seules les mesures manquent.
      popupHealthMetrics: (sites) => `Mesures de réponse indisponibles sur : ${sites}. Le coaching fonctionne normalement.`,
      popupCoverage: (pct) => `${pct} % des envois récents ont produit une mesure de réponse`,
      authEmail: "Email",
      authPassword: "Mot de passe",
      authLogin: "Se connecter",
      authSignup: "Créer un compte",
      authRequired: "Email et mot de passe requis.",
      authInvalid: "Identifiants invalides.",
      authConfirm: "Compte créé. Confirme ton email puis connecte-toi.",
      authHint: "Sans compte, tout reste local sur cet ordinateur.",
      authNoOrg: "aucune organisation rattachée",
      joinCodePlaceholder: "Code de classe (ex. ABC2345)",
      joinCta: "Rejoindre ma classe",
      joinInvalid: "Code invalide, désactivé ou expiré.",
      joinOtherOrg: "Ton compte est déjà rattaché à une autre organisation.",
      popupConsentLink: "🔒 Mes données partagées",
      // Divulgation à la jonction : rejoindre = partager les indicateurs.
      joinDiscTitle: "Avant de rejoindre",
      joinDiscBody:
        "Rejoindre une classe, c'est partager avec ton organisation : tes scores de qualité, catégories de prompts, nombres de mots, sites utilisés, issues (envoyé, amélioré, annulé) et dates, ainsi que la longueur et la durée des réponses de l'IA, le modèle utilisé et ton temps de lecture — jamais le texte de ces réponses. Jamais aucun texte sans ton accord séparé, catégorie par catégorie, à l'écran suivant. Ton email de compte t'identifie auprès de l'enseignant. Conservation : contenu 90 jours max, indicateurs 12 mois.",
      joinDiscAccept: "Rejoindre et partager ces indicateurs",
      joinDiscCancel: "Annuler",
      popupInertBanner: "Prompt Tracker est en veille : rien n'est enregistré tant que tu n'as pas accepté la divulgation des données.",
      popupInertCta: "Voir et activer",
      disclosureUpdate:
        "Nouveau en 0.7 : l'extension mesure aussi la réponse de l'IA — sa longueur, sa durée, le modèle utilisé et le temps que tu prends avant d'enchaîner. Le texte des réponses est compté puis oublié, jamais enregistré ni transmis.",
      disclosureUpdateOk: "J'ai compris",
      popupPrivacyLink: "Politique de confidentialité",
      popupMethodLink: "Comment le score et les modes sont calculés",
      modalMethodTitle: "Comment ce score est calculé (ouvre la page méthode)",
      toastSentImproved: (brand) => `Envoyé après ta réflexion avec ${brand} : compté « avec accompagnement ».`,
      toastSentDirect: "Envoyé tel quel : compté « direct, aide déclinée ».",
      // Consentement
      consentTitle: (org) => `Tes données partagées avec ${org}`,
      consentSubtitle: "C'est toi qui décides, catégorie par catégorie. Modifiable à tout moment.",
      consentBaseline:
        "Toujours partagé avec ton organisation : scores de qualité, catégories de prompts, nombres de mots, sites utilisés, issues (envoyé, amélioré, annulé) et dates, plus la longueur et la durée des réponses de l'IA, le modèle utilisé et ton temps de lecture. Jamais aucun contenu : le texte des réponses est compté, jamais enregistré. C'est ce qui alimente ta courbe de progression.",
      consentBaselineRetention:
        "Conservation : les contenus partagés sont effacés au bout de 90 jours, les indicateurs au bout de 12 mois. Tu peux tout effacer avant, à tout moment.",
      consentLlmNote:
        "Ton organisation a activé les questions sur mesure : si tu acceptes « texte de mes prompts » et « raisonnement socratique », ton prompt et ton dialogue transitent par notre serveur et par Anthropic (fournisseur IA, sans conservation) pour générer la prochaine question. Sinon, les questions viennent de la banque locale.",
      consentNoneRequested: (org) => `${org} ne demande aucun contenu. Rien d'autre que les indicateurs ne quitte ton navigateur.`,
      consentPurpose: (org) => `Pourquoi ${org} le demande`,
      catPromptText: "Le texte de mes prompts",
      catPromptTextDesc: "Ce que tu écris à l'IA, mot pour mot.",
      catDialogue: "Mon raisonnement socratique",
      catDialogueDesc: "Tes réponses aux questions du dialogue : ta réflexion avant l'envoi.",
      catPostReflection: "Mes réflexions d'après",
      catPostReflectionDesc: "Tes reformulations et vérifications après les réponses de l'IA.",
      catConversation: "Le fil de mes conversations",
      catConversationDesc: "Le regroupement de tes prompts par conversation (jamais le contenu des réponses de l'IA).",
      consentSave: "Valider mes choix",
      consentSaved: "Choix enregistrés ✓",
      consentDangerTitle: "Droit à l'effacement",
      consentPurge: "Effacer le contenu déjà partagé",
      consentPurgeConfirm: "Effacer définitivement le contenu déjà partagé (textes, raisonnements, fils de conversation) ? Tes indicateurs et scores restent.",
      consentPurgeDone: (n) => `Contenu effacé (${n} éléments). Tes indicateurs sont conservés.`,
      consentNotConnected: "Connecte-toi d'abord dans le popup de l'extension, puis reviens ici.",
      authConnected: "connecté",
      authPending: (n) => `${n} événement(s) en attente de synchronisation`,
      authSynced: "Tout est synchronisé ✓",
      // Bannière de synchronisation bloquée : dire ce qui manque, et donner
      // l'action qui le lève. Jamais d'échec muet.
      syncBlockedBaseline:
        "Rien n'est encore partagé avec ton organisation : il manque ton accord pour envoyer tes indicateurs (scores, catégories, compteurs). Aucun texte de prompt n'est concerné ici.",
      syncCtaBaseline: "Accepter et activer le partage",
      syncBlockedNoOrg:
        "Ton compte n'est rattaché à aucune classe. Saisis le code que t'a donné ton enseignant pour que ta progression lui remonte.",
      syncCtaNoOrg: "Rejoindre ma classe",
      syncBlockedNoAuth:
        "Tu n'es pas connecté : ta progression reste sur cet ordinateur et ne remonte pas à ta classe.",
      syncCtaNoAuth: "Lier mon compte",
      // Distinct de « pas connecté » : l'utilisateur ÉTAIT lié, sa session a
      // expiré. Le dire, sinon il glisse en mode local sans s'en apercevoir et
      // sa classe cesse de recevoir quoi que ce soit.
      syncBlockedExpired:
        "Ta session a expiré : tes prompts continuent d'être analysés sur cet ordinateur, mais ils ne remontent plus à ta classe. Rien n'est perdu, tout repartira à la reconnexion.",
      syncCtaExpired: "Me reconnecter",
      syncBlockedError: (msg) => `La synchronisation a échoué : ${msg}. Nouvel essai automatique dans une minute.`,
      syncPending: (n) => `${n} événement(s) en attente.`,
      syncPendingSince: (n, date) => `${n} événement(s) en attente depuis le ${date}.`,
      // Appairage : le compte se lie depuis le web, où l'utilisateur est déjà
      // connecté. Aucun mot de passe n'est saisi dans le popup.
      pairIntro:
        "Lie ton compte pour retrouver ta progression sur le web et la partager avec ta classe. Sans compte, tout reste sur cet ordinateur.",
      pairStart: "Lier mon compte",
      pairWaiting:
        "Vérifie que ce code est bien celui affiché dans l'onglet qui vient de s'ouvrir, puis autorise. La liaison se fait ensuite toute seule.",
      pairReopen: "Rouvrir la page",
      pairCancel: "Annuler",
      pairExpired: "Demande expirée ou déjà utilisée. Relance « Lier mon compte ».",
      pairFailed: "La liaison a échoué. Réessaie dans un instant.",
      pairRetrying: "Connexion au serveur difficile, nouvel essai en cours…",
      authFallback: "Se connecter avec un mot de passe",
      authPendingSignup: (email) =>
        `Compte créé pour ${email}. Confirme ton adresse depuis ta boîte mail, puis connecte-toi ici.`,
      authDashboard: "📊 Ouvrir le dashboard",
      authDashboardHint: "Le dashboard s'ouvre avec les mêmes identifiants (email et mot de passe) que l'extension.",
      authLogout: "Déconnexion",
      // Onboarding
      obTitle: "Bienvenue dans Prompt Tracker",
      obSubtitle: "Le garde-fou de ton prompting : un peu de friction, beaucoup de réflexion.",
      obPitch:
        "Comme les applications qui t'aident à décrocher de ton téléphone, Prompt Tracker ajoute une pause réfléchie avant tes prompts IA. Quand ta demande est trop vague, elle est retenue avant l'envoi et un dialogue socratique t'aide à penser par toi-même. Puis c'est toujours toi qui décides d'envoyer.",
      obHow: "Comment ça marche",
      obStep1: "Écris ton prompt sur ChatGPT, Claude, Gemini, Mistral ou Grok, comme d'habitude.",
      obStep2: "Sous le seuil de qualité, l'envoi est retenu : questions socratiques, une par une, aussi longtemps que tu veux.",
      obStep3: "Envoie ta version enrichie de ta réflexion, ou ta demande initiale telle quelle. Toujours ton choix.",
      // Divulgation bien visible (Chrome Web Store) : données, finalité,
      // destination, conservation. L'extension reste inerte avant l'accord.
      obDiscTitle: "Tes données : ce que l'extension enregistre, et pourquoi",
      obDiscCollectTitle: "Ce qui est enregistré",
      obDiscCollect:
        "Sur ChatGPT, Claude, Gemini, Mistral et Grok, l'extension enregistre pour chaque prompt : des scores de qualité, la catégorie, le nombre de mots, le site, la date, l'issue (envoyé, amélioré, annulé), tes réponses au dialogue socratique et tes réflexions d'après-réponse. Elle mesure aussi la réponse de l'IA — sa longueur, sa durée de génération, le modèle utilisé et le temps que tu prends avant d'enchaîner. Le texte de ces réponses est compté puis oublié : il n'est jamais enregistré. Le texte complet de tes prompts, lui, n'est enregistré que si tu actives l'option dédiée dans les réglages.",
      obDiscPurposeTitle: "Pourquoi",
      obDiscPurpose:
        "Uniquement pour te montrer ta progression (miroir socratique, premiers jets, séries) et, si tu choisis de rejoindre une classe, la partager avec ton enseignant.",
      obDiscWhereTitle: "Où ça va",
      obDiscWhere:
        "Tout reste sur cet ordinateur. Un envoi vers un serveur suppose deux choix de ta part : créer un compte, puis rejoindre une organisation. À ce moment-là, un second écran te demandera ton accord explicite avant tout partage.",
      obDiscRetentionTitle: "Conservation et droits",
      obDiscRetention:
        "Données locales : supprimables à tout moment depuis le popup (« Effacer les données »). Données partagées avec une organisation : contenu conservé 90 jours maximum, indicateurs 12 mois, effaçables à tout moment.",
      obDiscPolicyLink: "Politique de confidentialité",
      obAccept: "J'accepte et j'active Prompt Tracker",
      obAccepted: "Activé ✓",
      obLater: "Plus tard (l'extension reste inactive)",
      obThemeTitle: "Ton thème",
      obThresholdTitle: "Niveau de friction",
      obThresholdHint: "Les prompts sous ce score déclenchent le dialogue. 40 est un bon départ.",
      obProfileTitle: "Ton usage principal",
      obProfileHint: "Les questions parleront ta langue : devoir, livrable ou dossier.",
      obIntentionTitle: "Ton plan quand ça devient vague",
      obIntentionHint:
        "Formuler un plan « si…, alors… » double presque les chances de s'y tenir (Gollwitzer). Il sera rappelé dans le dialogue les premières semaines, puis s'effacera.",
      obIntentionDefault: "Si mon prompt est vague, alors je précise mon intention et mon contexte avant d'envoyer.",
      profileStudent: "Étudiant",
      profileConsultant: "Consultant / freelance",
      profileEmployee: "Salarié",
      profileOther: "Autre",
      obSites: "Fonctionne sur ChatGPT, Claude, Gemini, Mistral (Le Chat) et Grok.",
      obTry: "Essaye maintenant : ouvre ChatGPT et tape « fais mes devoirs ».",
    },
    en: {
      brandDefault: "Prompt Tracker",
      badgeActive: (name, threshold) =>
        `${name} active: on the first message of a thread, a prompt under ${threshold}/100 opens the reflection dialogue; after that, you're in charge. Click to collapse.`,
      badgeActiveNoScore: (name) =>
        `${name} active: on the first message of a thread, a prompt that is too vague opens the reflection dialogue; after that, you're in charge. Click to collapse.`,
      badgeWatch: (name) => `${name} active: interception off, your prompts are only analyzed locally.`,
      badgeBroken: (name) => `${name}. Warning, the site UI may have changed, capture needs checking.`,
      badgeStandby: "(standby)",
      badgeToggleLabel: "Socratic interception",
      badgeToggleOn: "Interception on — click to put on standby",
      badgeToggleOff: "On standby — click to turn interception back on",
      badgeToggleLocked: "Setting managed by your organization",
      toastTitle: "Socratic mirror",
      toastUseful: "👍 Helpful",
      toastPause: "Not in this thread",
      pauseConfirmed: "Got it, I'll let you roll. See you in the next conversation.",
      postTitle: "Second look",
      postPlaceholder: "One sentence, in your own words…",
      postReply: "Answer",
      postSkip: "Not this time",
      postThanks: "Noted. Your reflection counts toward your progress.",
      modalTitle: (name) => `${name}: let's think this through`,
      modalSub: (score) =>
        `Prompt held before sending. Initial score ${score}/100. Answer as many times as you like: you decide when to send.`,
      modalSubNoScore:
        "Prompt held before sending. Answer as many times as you like: it is up to you when to send.",
      modalPromise: "Once the discussion is launched, I won't interrupt you again in this thread.",
      modalIntention: (plan) => `Your plan: "${plan}"`,
      modalSubReentry: (score) =>
        `Three prompts in a row well below your usual level (latest: ${score}/100). Two minutes to regroup? You can always send as is.`,
      modalSubReentryNoScore:
        "Three prompts in a row well below your usual level. Two minutes to regroup? You can always send as is.",
      modalPause: "Leave me alone on this thread",
      modalAnswerPlaceholder: "Your answer… (Enter to submit, Shift+Enter for a new line)",
      modalReply: "Answer",
      modalSkip: "Skip this question",
      modalSkipped: "(question skipped)",
      modalOtherQuestion: "Another question",
      modalOtherQuestionTitle: "Rephrase or go deeper: a different, more demanding question.",
      modalBankExhausted: "Every question suited to this prompt has been asked. Answer or send when you're ready.",
      modalCoverageDone: (axes) =>
        `You have covered the essentials: ${axes}. It is up to you when to send.`,
      modalCoverageDoneShort: "You have laid out your thinking. It is up to you when to send.",
      modalOneMore: "Ask one more question",
      libraryHead: (n) => `Start from a prompt that worked (${n})`,
      libraryNote:
        "Published by your school. Clicking one loads it into the preview; “recompile from the dialogue” undoes it.",
      libraryOfficial: "Teaching team",
      libraryPeer: "Shared by a student",
      libraryCopies: (n) => `${n} reuses`,
      libraryHelpful: (n) => `${n} 👍`,
      libraryOffer: (name) => `${name} publishes a prompt library.`,
      libraryOfferHint:
        "The extension will read that page without sending your account, your prompts or any identifier. You can decline: nothing else changes.",
      libraryEnable: "Enable the library",
      libraryEnabled: "Library enabled.",
      libraryDenied: "Permission declined. You can try again whenever you like.",
      libraryPanelHead: (n) => `Prompt library (${n})`,
      libraryPanelNote:
        "Published by your school. Clicking copies the prompt — paste it into your chat and adapt it.",
      librarySearch: "Search…",
      libraryCopied: "Copied!",
      libraryCopyFailed: "Couldn't copy.",
      libraryLoading: "Loading the library…",
      libraryEmptyPanel: "No prompts published yet.",
      libraryNoMatch: "No prompt matches.",
      modalLlmBadge: "AI-generated question",
      modalLlmNotice: "AI-tailored questions: your prompt and answers transit through the server (per your consents), without being stored. If slow, automatic fallback to the local bank.",
      llmAxisLabel: "My reflection",
      modalPreviewHead: "Prompt that will be sent: score",
      modalPreviewHeadNoScore: "Prompt that will be sent",
      rubClarte: "Clarity",
      rubContexte: "Context",
      rubCritique: "Critical eye",
      modalRecompile: "recompile from the dialogue",
      modalSend: "🚀 Send to chat (with my reasoning)",
      modalSendAnyway: "Send my original request as is",
      modalCancelTitle: "Cancel (nothing is sent, your text stays in the input box)",
      compileHeader: "My prior reasoning:",
      popupTagline: "The guardrail for your prompting",
      popupPrompts: "prompts",
      popupAvgScore: "first drafts",
      popupTrend: "7-day trend",
      popupMirror: "day streak",
      popupStreakTitle: (n) => (n >= 2 ? `${n} days in a row of first drafts at level. That's YOUR progress, no coaching.` : "Consecutive days where your first drafts (before any coaching) reach the threshold."),
      popupStreakFreeze: (n) => (n === 1 ? "1 freeze banked: one missed day won't break your streak." : `${n} freezes banked: earned with every full successful week.`),
      popupEffThreshold: (base, eff) => (eff > base ? `Effective threshold: ${eff} (the bar rises with your streaks)` : ""),
      popupRubrics: "Rubrics (average /25)",
      popupCategories: "Usage categories",
      popupSettings: "Settings",
      popupThemeLabel: "Theme",
      themeLight: "Light",
      themeDark: "Dark",
      themeSystem: "System",
      popupIntercept: "Socratic interception enabled",
      popupThreshold: "Interception threshold:",
      popupFullText: "Keep prompt text (otherwise: indicators only)",
      popupExport: "⬇️ Export CSV",
      popupReset: "Clear data",
      popupResetConfirm: "Clear all local data?",
      popupEmpty: "No prompts captured yet. Use ChatGPT, Claude, Gemini, Mistral or Grok, I've got you. 🙂",
      popupHealthBroken: (sites) => `⚠️ Capture may be broken on: ${sites} (UI changed)`,
      // Soft warning: coaching works, only the measurements are missing.
      popupHealthMetrics: (sites) => `Response measurements unavailable on: ${sites}. Coaching works as usual.`,
      popupCoverage: (pct) => `${pct}% of recent sends produced a response measurement`,
      authEmail: "Email",
      authPassword: "Password",
      authLogin: "Sign in",
      authSignup: "Create account",
      authRequired: "Email and password required.",
      authInvalid: "Invalid credentials.",
      authConfirm: "Account created. Confirm your email, then sign in.",
      authHint: "Without an account, everything stays local on this computer.",
      authNoOrg: "no organization attached",
      joinCodePlaceholder: "Class code (e.g. ABC2345)",
      joinCta: "Join my class",
      joinInvalid: "Invalid, disabled or expired code.",
      joinOtherOrg: "Your account already belongs to another organization.",
      popupConsentLink: "🔒 My shared data",
      joinDiscTitle: "Before you join",
      joinDiscBody:
        "Joining a class means sharing with your organization: your quality scores, prompt categories, word counts, sites used, outcomes (sent, improved, cancelled) and dates, plus the length and duration of the AI's answers, the model used and your reading time — never the text of those answers. Never any text without your separate, category-by-category consent on the next screen. Your account email identifies you to the teacher. Retention: content 90 days max, indicators 12 months.",
      joinDiscAccept: "Join and share these indicators",
      joinDiscCancel: "Cancel",
      popupInertBanner: "Prompt Tracker is on standby: nothing is recorded until you accept the data disclosure.",
      popupInertCta: "Review and enable",
      disclosureUpdate:
        "New in 0.7: the extension also measures the AI's answer — its length, how long it took, the model used, and how long you take before sending the next prompt. The text of those answers is counted then forgotten, never recorded or transmitted.",
      disclosureUpdateOk: "Got it",
      popupPrivacyLink: "Privacy policy",
      popupMethodLink: "How the score and modes are computed",
      modalMethodTitle: "How this score is computed (opens the method page)",
      toastSentImproved: (brand) => `Sent after your work with ${brand}: counted as "coached".`,
      toastSentDirect: 'Sent as is: counted as "direct, help declined".',
      consentTitle: (org) => `Your data shared with ${org}`,
      consentSubtitle: "You decide, category by category. Changeable at any time.",
      consentBaseline:
        "Always shared with your organization: quality scores, prompt categories, word counts, sites used, outcomes (sent, improved, cancelled) and dates, plus the length and duration of the AI's answers, the model used and your reading time. Never any content: the text of the answers is counted, never recorded. This is what feeds your progress curve.",
      consentBaselineRetention:
        "Retention: shared content is erased after 90 days, indicators after 12 months. You can erase everything sooner, at any time.",
      consentLlmNote:
        "Your organization enabled tailored questions: if you accept \"the text of my prompts\" and \"my Socratic reasoning\", your prompt and dialogue transit through our server and Anthropic (AI provider, no retention) to generate the next question. Otherwise, questions come from the local bank.",
      consentNoneRequested: (org) => `${org} requests no content. Nothing but indicators ever leaves your browser.`,
      consentPurpose: (org) => `Why ${org} asks for it`,
      catPromptText: "The text of my prompts",
      catPromptTextDesc: "What you write to the AI, word for word.",
      catDialogue: "My Socratic reasoning",
      catDialogueDesc: "Your answers to the dialogue questions: your thinking before sending.",
      catPostReflection: "My afterthoughts",
      catPostReflectionDesc: "Your restatements and verifications after the AI's answers.",
      catConversation: "My conversation threads",
      catConversationDesc: "The grouping of your prompts by conversation (never the AI's answers).",
      consentSave: "Confirm my choices",
      consentSaved: "Choices saved ✓",
      consentDangerTitle: "Right to erasure",
      consentPurge: "Erase already shared content",
      consentPurgeConfirm: "Permanently erase already shared content (texts, reasoning, conversation threads)? Your indicators and scores remain.",
      consentPurgeDone: (n) => `Content erased (${n} items). Your indicators are kept.`,
      consentNotConnected: "Sign in from the extension popup first, then come back here.",
      authConnected: "signed in",
      authPending: (n) => `${n} event(s) awaiting sync`,
      authSynced: "Everything is synced ✓",
      syncBlockedBaseline:
        "Nothing is shared with your organisation yet: your agreement is missing to send your indicators (scores, categories, counters). No prompt text is involved here.",
      syncCtaBaseline: "Accept and enable sharing",
      syncBlockedNoOrg:
        "Your account isn't linked to any class. Enter the code your teacher gave you so your progress reaches them.",
      syncCtaNoOrg: "Join my class",
      syncBlockedNoAuth:
        "You're not signed in: your progress stays on this computer and doesn't reach your class.",
      syncCtaNoAuth: "Link my account",
      syncBlockedExpired:
        "Your session has expired: your prompts are still analyzed on this computer, but they no longer reach your class. Nothing is lost, everything will be sent again once you reconnect.",
      syncCtaExpired: "Reconnect",
      syncBlockedError: (msg) => `Sync failed: ${msg}. Automatic retry in one minute.`,
      syncPending: (n) => `${n} event(s) pending.`,
      syncPendingSince: (n, date) => `${n} event(s) pending since ${date}.`,
      pairIntro:
        "Link your account to find your progress on the web and share it with your class. Without an account, everything stays on this computer.",
      pairStart: "Link my account",
      pairWaiting:
        "Check that this code matches the one in the tab that just opened, then authorise. Linking then happens on its own.",
      pairReopen: "Reopen the page",
      pairCancel: "Cancel",
      pairExpired: "Request expired or already used. Start « Link my account » again.",
      pairFailed: "Linking failed. Try again in a moment.",
      pairRetrying: "Trouble reaching the server, retrying…",
      authFallback: "Sign in with a password",
      authPendingSignup: (email) =>
        `Account created for ${email}. Confirm your address from your inbox, then sign in here.`,
      authDashboard: "📊 Open dashboard",
      authDashboardHint: "The dashboard uses the same email and password as the extension.",
      authLogout: "Sign out",
      obTitle: "Welcome to Prompt Tracker",
      obSubtitle: "The guardrail for your prompting: a little friction, a lot of thinking.",
      obPitch:
        "Like the apps that help you unglue from your phone, Prompt Tracker adds a thoughtful pause before your AI prompts. When your request is too vague, it is held before sending and a Socratic dialogue helps you think for yourself. Then you always decide when to send.",
      obHow: "How it works",
      obStep1: "Write your prompt on ChatGPT, Claude, Gemini, Mistral or Grok, as usual.",
      obStep2: "Below the quality threshold, sending is held: Socratic questions, one at a time, for as long as you want.",
      obStep3: "Send your version enriched with your reasoning, or your original request as is. Always your call.",
      obDiscTitle: "Your data: what the extension records, and why",
      obDiscCollectTitle: "What is recorded",
      obDiscCollect:
        "On ChatGPT, Claude, Gemini, Mistral and Grok, the extension records for each prompt: quality scores, the category, the word count, the site, the date, the outcome (sent, improved, cancelled), your answers to the Socratic dialogue and your post-response reflections. It also measures the AI's answer — its length, how long it took to generate, the model used, and how long you take before sending the next prompt. The text of those answers is counted then forgotten: it is never recorded. The full text of your prompts is only recorded if you enable the dedicated setting.",
      obDiscPurposeTitle: "Why",
      obDiscPurpose:
        "Solely to show you your progress (Socratic mirror, first drafts, streaks) and, if you choose to join a class, to share it with your teacher.",
      obDiscWhereTitle: "Where it goes",
      obDiscWhere:
        "Everything stays on this computer. Sending anything to a server takes two choices on your part: creating an account, then joining an organization. At that point, a second screen will ask for your explicit consent before any sharing.",
      obDiscRetentionTitle: "Retention and rights",
      obDiscRetention:
        "Local data: deletable at any time from the popup (\"Clear data\"). Data shared with an organization: content kept 90 days maximum, indicators 12 months, erasable at any time.",
      obDiscPolicyLink: "Privacy policy",
      obAccept: "I accept and turn on Prompt Tracker",
      obAccepted: "Enabled ✓",
      obLater: "Later (the extension stays off)",
      obThemeTitle: "Your theme",
      obThresholdTitle: "Friction level",
      obThresholdHint: "Prompts under this score trigger the dialogue. 40 is a good start.",
      obProfileTitle: "Your main use",
      obProfileHint: "Questions will speak your language: assignment, deliverable or file.",
      obIntentionTitle: "Your plan for when it gets vague",
      obIntentionHint:
        "Writing an \"if…, then…\" plan nearly doubles follow-through (Gollwitzer). It will be shown in the dialogue for the first few weeks, then fade away.",
      obIntentionDefault: "If my prompt is vague, then I state my intent and context before sending.",
      profileStudent: "Student",
      profileConsultant: "Consultant / freelancer",
      profileEmployee: "Employee",
      profileOther: "Other",
      obSites: "Works on ChatGPT, Claude, Gemini, Mistral (Le Chat) and Grok.",
      obTry: "Try it now: open ChatGPT and type \"do my homework\".",
    },
  };

  function detectLang() {
    try {
      const ui =
        (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getUILanguage && chrome.i18n.getUILanguage()) ||
        navigator.language ||
        "fr";
      return ui.toLowerCase().startsWith("fr") ? "fr" : "en";
    } catch {
      return "fr";
    }
  }

  const lang = detectLang();

  function t(key, ...args) {
    const entry = (MESSAGES[lang] && MESSAGES[lang][key]) || MESSAGES.fr[key];
    return typeof entry === "function" ? entry(...args) : entry;
  }

  return { t, lang };
})();

if (typeof self !== "undefined") self.CoachI18n = CoachI18n;
