// Popup : login, stats rapides, réglages (dont thème), export CSV.
// Les stats détaillées vivent dans le dashboard web ; ici, l'essentiel.

const DASHBOARD_URL = "https://track-prompt.vercel.app";

// Garde-fou : une erreur d'init ne doit jamais laisser un popup vide et muet
// (retour terrain). i18n peut être la cause : message bilingue en dur.
window.addEventListener("error", (event) => {
  const el = document.getElementById("fatal");
  if (!el || !el.hidden) return;
  el.textContent =
    "Le popup a rencontré une erreur : " + event.message +
    ". Recharge l'extension via chrome://extensions. / The popup hit an error, reload the extension from chrome://extensions.";
  el.hidden = false;
});

const t = (...a) => CoachI18n.t(...a);

/* ---------- i18n ---------- */

for (const el of document.querySelectorAll("[data-i18n]")) el.textContent = t(el.dataset.i18n);
document.getElementById("auth-email").placeholder = t("authEmail");
document.getElementById("auth-password").placeholder = t("authPassword");
document.getElementById("auth-login").textContent = t("authLogin");
document.getElementById("auth-signup").textContent = t("authSignup");
document.getElementById("open-dashboard").textContent = t("authDashboard");
document.getElementById("auth-logout").textContent = t("authLogout");
document.getElementById("export").textContent = t("popupExport");
document.getElementById("reset").textContent = t("popupReset");
document.getElementById("privacy-link").textContent = t("popupPrivacyLink");
document.getElementById("method-link").textContent = t("popupMethodLink");
document.getElementById("inert-text").textContent = t("popupInertBanner");
document.getElementById("inert-cta").textContent = t("popupInertCta");

/* ---------- Veille avant acceptation de la divulgation ---------- */

// Tant que la divulgation (onboarding) n'a pas été acceptée, l'extension est
// inerte : bandeau explicite, compte et réglages masqués, rien n'est capturé.
chrome.storage.local.get("disclosure", (data) => {
  const accepted = Boolean(data.disclosure && data.disclosure.accepted);
  document.getElementById("inert-banner").hidden = accepted;
  document.getElementById("auth").hidden = !accepted;
  document.querySelector(".settings").hidden = !accepted;
});

document.getElementById("inert-cta").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("onboarding/onboarding.html") });
});

/* ---------- Thème ---------- */

function applyTheme(setting) {
  const dark =
    setting === "dark" ||
    (setting === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
  for (const btn of document.querySelectorAll("[data-theme-choice]")) {
    btn.classList.toggle("active", btn.dataset.themeChoice === setting);
  }
}

for (const btn of document.querySelectorAll("[data-theme-choice]")) {
  btn.addEventListener("click", () => {
    const theme = btn.dataset.themeChoice;
    applyTheme(theme);
    chrome.storage.local.get("settings", (data) => {
      chrome.storage.local.set({ settings: { ...(data.settings || {}), theme } });
    });
  });
}

window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
  chrome.storage.local.get("settings", (data) => applyTheme((data.settings || {}).theme || "light"));
});

/* ---------- Authentification & sync ---------- */

function showAuthState(session, profile, orgConfig, pendingCount) {
  const form = document.getElementById("auth-form");
  const connected = document.getElementById("auth-connected");
  if (session) {
    form.hidden = true;
    connected.hidden = false;
    document.getElementById("auth-user").textContent = session.email || t("authConnected");
    document.getElementById("auth-org").textContent =
      orgConfig && orgConfig.branding ? orgConfig.branding.name : t("authNoOrg");
    document.getElementById("sync-status").textContent = pendingCount ? t("authPending", pendingCount) : t("authSynced");
    // Sans organisation : proposer le rattachement par code de classe.
    // Avec : l'accès permanent aux choix de partage (consentement).
    document.getElementById("join-org").hidden = Boolean(orgConfig);
    document.getElementById("open-consent").hidden = !orgConfig;
    if (orgConfig && orgConfig.branding) {
      document.getElementById("brand-title").textContent = orgConfig.branding.name;
      if (orgConfig.branding.color) {
        document.documentElement.style.setProperty("--accent", orgConfig.branding.color);
      }
    }
  } else {
    form.hidden = false;
    connected.hidden = true;
  }
}

/* ---------- Rejoindre une classe par code ---------- */

document.getElementById("join-code").placeholder = t("joinCodePlaceholder");
document.getElementById("join-submit").textContent = t("joinCta");
document.getElementById("open-consent").textContent = t("popupConsentLink");
document.getElementById("join-disc-title").textContent = t("joinDiscTitle");
document.getElementById("join-disc-body").textContent = t("joinDiscBody");
document.getElementById("join-disc-accept").textContent = t("joinDiscAccept");
document.getElementById("join-disc-cancel").textContent = t("joinDiscCancel");

const CONSENT_URL = chrome.runtime.getURL("consent/consent.html");
document.getElementById("open-consent").addEventListener("click", () => {
  chrome.tabs.create({ url: CONSENT_URL });
});

function joinError(message) {
  const el = document.getElementById("join-error");
  el.textContent = message;
  el.hidden = !message;
}

// Jonction en deux temps (divulgation bien visible) : le premier clic déplie
// ce que « rejoindre » partage avec l'organisation ; seul le bouton d'accord
// déclenche réellement la jonction, et donc la synchronisation.
document.getElementById("join-submit").addEventListener("click", () => {
  joinError("");
  if (!document.getElementById("join-code").value.trim()) return;
  document.getElementById("join-disclosure").hidden = false;
  document.getElementById("join-submit").disabled = true;
});

document.getElementById("join-disc-cancel").addEventListener("click", () => {
  document.getElementById("join-disclosure").hidden = true;
  document.getElementById("join-submit").disabled = false;
});

document.getElementById("join-disc-accept").addEventListener("click", async () => {
  joinError("");
  const code = document.getElementById("join-code").value.trim();
  if (!code) return;
  try {
    await CoachApi.joinGroup(code);
    // L'accord donné ici couvre le socle d'indicateurs : c'est lui que la
    // sync vérifie avant de pousser quoi que ce soit (baselineConsent).
    await new Promise((r) =>
      chrome.storage.local.set(
        { baselineConsent: { accepted: true, version: 1, acceptedAt: new Date().toISOString() } },
        r
      )
    );
    document.getElementById("join-disclosure").hidden = true;
    document.getElementById("join-submit").disabled = false;
    chrome.runtime.sendMessage({ type: "sync-now" }, () => refreshAuthUi());
    // Le consentement se présente immédiatement après l'adhésion : c'est
    // l'utilisateur qui décide ce que l'organisation recevra en plus du socle.
    chrome.tabs.create({ url: CONSENT_URL });
  } catch (e) {
    if (String(e.message).includes("invalid_code")) joinError(t("joinInvalid"));
    else if (String(e.message).includes("already_in_other_org")) joinError(t("joinOtherOrg"));
    else joinError(e.message);
  }
});

function authError(message) {
  const el = document.getElementById("auth-error");
  el.textContent = message;
  el.hidden = !message;
}

async function handleAuth(kind) {
  authError("");
  const email = document.getElementById("auth-email").value.trim();
  const password = document.getElementById("auth-password").value;
  if (!email || !password) return authError(t("authRequired"));
  try {
    const session = kind === "login" ? await CoachApi.login(email, password) : await CoachApi.signup(email, password);
    if (!session) return authError(t("authConfirm"));
    chrome.runtime.sendMessage({ type: "sync-now" }, () => refreshAuthUi());
  } catch (e) {
    authError(e.message === "Invalid login credentials" ? t("authInvalid") : e.message);
  }
}

function refreshAuthUi() {
  chrome.storage.local.get(["session", "profile", "orgConfig", "events"], (data) => {
    const pending = (data.events || []).filter((e) => !e.synced).length;
    showAuthState(data.session, data.profile, data.orgConfig, pending);
  });
}

document.getElementById("auth-login").addEventListener("click", () => handleAuth("login"));
document.getElementById("auth-signup").addEventListener("click", () => handleAuth("signup"));
document.getElementById("auth-logout").addEventListener("click", async () => {
  await CoachApi.logout();
  refreshAuthUi();
});
document.getElementById("open-dashboard").addEventListener("click", () => {
  chrome.tabs.create({ url: DASHBOARD_URL });
});
refreshAuthUi();

/* ---------- Stats locales ---------- */

const RUBRICS = [
  ["clarte", { fr: "Clarté", en: "Clarity" }],
  ["contexte", { fr: "Contexte", en: "Context" }],
  ["iteration", { fr: "Itération", en: "Iteration" }],
  ["critique", { fr: "Esprit critique", en: "Critical thinking" }],
];

function avg(arr) {
  return arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
}

function render(events, threshold) {
  document.getElementById("stat-count").textContent = events.length;

  // La métrique principale est le PREMIER JET : ce que l'utilisateur écrit
  // seul, avant tout coaching. C'est la seule mesure honnête de l'apprentissage.
  const firstDrafts = events.map((e) => CoachScoring.firstDraftScore(e)).filter((s) => s !== null);
  document.getElementById("stat-score").textContent = firstDrafts.length ? `${Math.round(avg(firstDrafts))}/100` : "–";

  const now = Date.now();
  const week = 7 * 24 * 3600 * 1000;
  const draft = (e) => CoachScoring.firstDraftScore(e);
  const recent = events.filter((e) => now - Date.parse(e.ts) < week).map(draft).filter((s) => s !== null);
  const before = events.filter((e) => now - Date.parse(e.ts) >= week && now - Date.parse(e.ts) < 2 * week).map(draft).filter((s) => s !== null);
  const trendEl = document.getElementById("stat-trend");
  if (recent.length && before.length) {
    const delta = Math.round(avg(recent) - avg(before));
    trendEl.textContent = `${delta >= 0 ? "+" : ""}${delta}`;
  } else {
    trendEl.textContent = "–";
  }

  // Série de jours où les premiers jets tiennent le seuil : on célèbre
  // l'autonomie, pas la dépendance au coaching.
  const { streak, freezes } = CoachScoring.dayStreakInfo(events, threshold);
  const streakEl = document.getElementById("stat-mirror");
  streakEl.textContent = streak ? `${streak} 🔥${freezes ? ` +${freezes}🧊` : ""}` : "–";
  streakEl.parentElement.title =
    t("popupStreakTitle", streak) + (freezes ? ` ${t("popupStreakFreeze", freezes)}` : "");

  const rubricsEl = document.getElementById("rubrics");
  rubricsEl.textContent = "";
  if (!events.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = t("popupEmpty");
    rubricsEl.appendChild(p);
  } else {
    for (const [key, labels] of RUBRICS) {
      const value = avg(events.map((e) => e.scores[key]));
      const rubric = document.createElement("div");
      rubric.className = "rubric";
      const row = document.createElement("div");
      row.className = "row";
      const name = document.createElement("span");
      name.textContent = labels[CoachI18n.lang] || labels.fr;
      const val = document.createElement("span");
      val.textContent = `${value.toFixed(1)}/25`;
      row.append(name, val);
      const bar = document.createElement("div");
      bar.className = "bar";
      const fill = document.createElement("div");
      fill.className = "fill";
      fill.style.width = `${(value / 25) * 100}%`;
      bar.appendChild(fill);
      rubric.append(row, bar);
      rubricsEl.appendChild(rubric);
    }
  }

  const byCategory = {};
  for (const e of events) byCategory[e.category] = (byCategory[e.category] || 0) + 1;
  const catEl = document.getElementById("categories");
  catEl.textContent = "";
  for (const [cat, count] of Object.entries(byCategory).sort((a, b) => b[1] - a[1])) {
    const li = document.createElement("li");
    const b = document.createElement("b");
    b.textContent = count;
    li.append(`${cat} `, b);
    catEl.appendChild(li);
  }
}

// Colonnes alignées sur le contrat d'intégration (docs/INTEGRATION.md) :
// mêmes noms que l'API et l'export admin, un seul pipeline lit les trois.
function toCsv(events) {
  const header = ["client_event_id", "ts", "site", "category", "words", "score_clarte", "score_contexte", "score_iteration", "score_critique", "score_total", "intercepted", "outcome", "score_before", "score_after", "rounds", "answers_count", "mirror_shown", "mirror_feedback", "conv_key", "text"];
  const escape = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const rows = events.map((e) =>
    [e.id, e.ts, e.site, e.category, e.words, e.scores.clarte, e.scores.contexte, e.scores.iteration, e.scores.critique, e.scores.total, e.intercepted ?? false, e.outcome ?? "", e.scoreBefore ?? "", e.scoreAfter ?? "", e.rounds ?? 0, e.answersCount ?? 0, e.mirrorShown, e.mirrorFeedback ?? "", e.conv ?? "", e.text ?? ""].map(escape).join(";")
  );
  return [header.join(";"), ...rows].join("\n");
}

chrome.storage.local.get(["events", "settings", "health_chatgpt", "health_claude", "health_gemini", "health_mistral", "health_grok"], (data) => {
  const events = data.events || [];
  const settings = { captureMode: "metadata", interceptEnabled: true, threshold: 40, theme: "light", ...(data.settings || {}) };
  render(events, settings.threshold);

  applyTheme(settings.theme);
  document.getElementById("setting-mirror").checked = settings.interceptEnabled;
  document.getElementById("setting-fulltext").checked = settings.captureMode === "full";
  document.getElementById("setting-threshold").value = settings.threshold;
  document.getElementById("threshold-value").textContent = settings.threshold;

  // Fading : quand les séries réussies ont relevé la barre, on le dit.
  const eff = CoachScoring.adaptiveThreshold(events, settings.threshold);
  const effEl = document.getElementById("eff-threshold");
  const effText = t("popupEffThreshold", settings.threshold, eff);
  effEl.textContent = effText;
  effEl.hidden = !effText;

  const broken = [
    ["ChatGPT", data.health_chatgpt],
    ["Claude", data.health_claude],
    ["Gemini", data.health_gemini],
    ["Mistral", data.health_mistral],
    ["Grok", data.health_grok],
  ].filter(([, h]) => h && !h.healthy);
  if (broken.length) {
    const el = document.getElementById("health");
    el.textContent = t("popupHealthBroken", broken.map(([site]) => site).join(", "));
    el.hidden = false;
  }
});

document.getElementById("setting-mirror").addEventListener("change", (e) => {
  chrome.storage.local.get("settings", (data) => {
    chrome.storage.local.set({ settings: { ...(data.settings || {}), interceptEnabled: e.target.checked } });
  });
});

document.getElementById("setting-threshold").addEventListener("input", (e) => {
  const threshold = Number(e.target.value);
  document.getElementById("threshold-value").textContent = threshold;
  chrome.storage.local.get("settings", (data) => {
    chrome.storage.local.set({ settings: { ...(data.settings || {}), threshold } });
  });
});

document.getElementById("setting-fulltext").addEventListener("change", (e) => {
  chrome.storage.local.get("settings", (data) => {
    chrome.storage.local.set({ settings: { ...(data.settings || {}), captureMode: e.target.checked ? "full" : "metadata" } });
  });
});

document.getElementById("export").addEventListener("click", () => {
  chrome.storage.local.get("events", (data) => {
    const blob = new Blob(["﻿" + toCsv(data.events || [])], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `prompt-tracker-export-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  });
});

document.getElementById("reset").addEventListener("click", () => {
  if (confirm(t("popupResetConfirm"))) {
    chrome.storage.local.remove(
      ["events", "postEvents", "postConvs", "postCount", "health_chatgpt", "health_claude", "health_gemini", "health_mistral", "health_grok"],
      () => render([], 40)
    );
  }
});
