// Repère visuel dans l'UI du chat : une pastille discrète en bas à droite qui
// montre que le coach est actif (aux couleurs white-label de l'organisation).
// Cliquable pour se replier en point discret ; passe en orange si la sonde de
// santé détecte que l'UI du site a changé (capture peut-être cassée).

const CoachBadge = (() => {
  let host = null;
  let collapsed = false;

  function render(state) {
    // state: { branding: {name, color, logoUrl}, healthy: bool, threshold, interceptEnabled }
    if (!host || !document.contains(host)) {
      host = document.createElement("div");
      host.id = "coach-ia-badge";
      const shadow = host.attachShadow({ mode: "open" });
      shadow.innerHTML = `
        <style>
          :host { all: initial; }
          .badge { position: fixed; bottom: 18px; right: 18px; z-index: 2147483646;
            display: flex; align-items: center; gap: 7px; padding: 6px 12px 6px 8px;
            border-radius: 999px; background: #1e1b2e; color: #f4f2ff;
            border: 1px solid var(--accent); box-shadow: 0 4px 14px rgba(0,0,0,.3);
            font: 12px/1 -apple-system, "Segoe UI", sans-serif; cursor: pointer;
            user-select: none; transition: opacity .2s, transform .2s; }
          .badge:hover { transform: translateY(-1px); }
          .badge.warn { border-color: #ffb347; }
          .badge.warn .dot { background: #ffb347; animation: none; }
          .dot { width: 8px; height: 8px; border-radius: 50%; background: var(--accent);
            animation: pulse 2.4s ease-in-out infinite; }
          @keyframes pulse { 0%,100% { opacity: 1 } 50% { opacity: .35 } }
          .logo { width: 16px; height: 16px; border-radius: 4px; object-fit: cover; }
          .name { font-weight: 600; letter-spacing: .01em; }
          .off { color: #8f86b3; font-weight: 400; }
          .badge.collapsed { padding: 6px; gap: 0; }
          .badge.collapsed .name, .badge.collapsed .logo, .badge.collapsed .off { display: none; }
        </style>
        <div class="badge" role="status"></div>`;
      document.documentElement.appendChild(host);
      shadow.querySelector(".badge").addEventListener("click", () => {
        collapsed = !collapsed;
        shadow.querySelector(".badge").classList.toggle("collapsed", collapsed);
      });
    }

    const shadow = host.shadowRoot;
    const badge = shadow.querySelector(".badge");
    const accent = (state.branding && state.branding.color) || "#6d5bd0";
    badge.style.setProperty("--accent", accent);
    badge.classList.toggle("warn", state.healthy === false);
    badge.classList.toggle("collapsed", collapsed);

    const name = (state.branding && state.branding.name) || "Coach IA";
    badge.title =
      state.healthy === false
        ? `${name} — attention : l'UI du site a peut-être changé, la capture est à vérifier.`
        : state.interceptEnabled === false
          ? `${name} actif — interception désactivée, tes prompts sont seulement analysés localement.`
          : `${name} actif — tes prompts sous ${state.threshold ?? 40}/100 déclencheront un dialogue de réflexion. Clique pour replier.`;

    badge.textContent = "";
    const dot = document.createElement("span");
    dot.className = "dot";
    badge.appendChild(dot);
    if (state.branding && state.branding.logoUrl) {
      const img = document.createElement("img");
      img.className = "logo";
      img.src = state.branding.logoUrl;
      img.alt = "";
      badge.appendChild(img);
    }
    const label = document.createElement("span");
    label.className = "name";
    label.textContent = state.healthy === false ? `${name} ⚠️` : name;
    badge.appendChild(label);
    if (state.interceptEnabled === false) {
      const off = document.createElement("span");
      off.className = "off";
      off.textContent = "(veille)";
      badge.appendChild(off);
    }
  }

  return { render };
})();
