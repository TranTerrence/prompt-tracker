// Analyse 100 % locale des prompts : catégorie + score qualité sur 4 rubriques.
// Aucun texte ne quitte le navigateur ; seul le résultat de cette analyse est stocké.

const CoachScoring = (() => {
  const CATEGORIES = [
    { key: "code", re: /\b(code|script|fonction|bug|erreur|python|javascript|sql|api|regex|debug)\b/i },
    { key: "rédaction", re: /\b(rédige|écris|écrire|mail|email|lettre|article|post|texte|message|réponds)\b/i },
    { key: "résumé", re: /\b(résume|résumé|synthèse|synthétise|tl;?dr|points clés)\b/i },
    { key: "traduction", re: /\b(traduis|traduction|translate|en anglais|en français|en espagnol)\b/i },
    { key: "analyse", re: /\b(analyse|compare|évalue|avantages|inconvénients|pour et contre|critique)\b/i },
    { key: "brainstorming", re: /\b(idées|brainstorm|propose|suggère|imagine|liste de)\b/i },
    { key: "recherche", re: /\b(qu'est[- ]ce|c'est quoi|qui est|quand|combien|pourquoi|explique|définis|définition)\b/i },
  ];

  const CONTEXT_MARKERS = /\b(contexte|je suis|nous sommes|mon objectif|pour (un|une|mon|ma|mes|des)|à destination de|public|audience|ton|format|contrainte|en tant que|tu es|agis comme|maximum|minimum|étapes?)\b/i;
  const ITERATION_MARKERS = /\b(reformule|améliore|plutôt|à la place|reprends|corrige|ajuste|modifie|précédent|ta (réponse|proposition)|cette (réponse|version)|plus (court|long|simple|détaillé)|autrement|version)\b/i;
  const CRITICAL_MARKERS = /\b(sources?|vérifie|fiable|limites?|risques?|biais|alternatives?|contre[- ]arguments?|pourquoi|justifie|nuance|incertitudes?|hypothèses?|es[- ]tu sûr)\b/i;
  const ACTION_VERB = /\b(rédige|écris|explique|analyse|compare|résume|traduis|propose|liste|crée|génère|corrige|améliore|évalue|décris|calcule|trouve|donne|fais|montre|aide)\b/i;
  const FULL_DELEGATION = /^\s*(fais|écris|rédige|génère|crée|fais[- ]moi|donne[- ]moi)\b/i;

  function wordCount(text) {
    return text.trim().split(/\s+/).filter(Boolean).length;
  }

  function categorize(text) {
    for (const c of CATEGORIES) if (c.re.test(text)) return c.key;
    return "autre";
  }

  // Chaque rubrique vaut 0–25 ; le score total est sur 100.
  function score(text, previousPrompts = []) {
    const words = wordCount(text);

    let clarte = 0;
    if (words >= 8) clarte += 10;
    if (words >= 20) clarte += 5;
    if (ACTION_VERB.test(text)) clarte += 7;
    if (/[?.!]/.test(text)) clarte += 3;

    let contexte = 0;
    if (CONTEXT_MARKERS.test(text)) contexte += 15;
    if (words >= 30) contexte += 5;
    if (/:\s|«|"|```/.test(text)) contexte += 5; // matière fournie (citation, données, code)

    let iteration = 0;
    if (ITERATION_MARKERS.test(text)) iteration += 20;
    if (previousPrompts.length > 0 && words < wordCount(previousPrompts[previousPrompts.length - 1] || "") * 3) iteration += 5;

    let critique = 0;
    if (CRITICAL_MARKERS.test(text)) critique += 20;
    if (/\b(2|deux|3|trois|plusieurs) (options|versions|approches|angles)\b/i.test(text)) critique += 5;

    const clamp = (v) => Math.min(25, v);
    const scores = {
      clarte: clamp(clarte),
      contexte: clamp(contexte),
      iteration: clamp(iteration),
      critique: clamp(critique),
    };
    scores.total = scores.clarte + scores.contexte + scores.iteration + scores.critique;
    return scores;
  }

  // Retourne une suggestion socratique (string) ou null si le prompt est bon.
  function socraticSuggestion(text, scores, recentEvents = []) {
    if (wordCount(text) < 8) {
      return "Quel résultat précis attends-tu ? Ajoute le contexte, le public visé et le format souhaité — ta réponse n'en sera que meilleure.";
    }
    if (FULL_DELEGATION.test(text) && scores.contexte < 10) {
      return "Qu'as-tu déjà essayé ou pensé ? Décris ta piste : l'IA la renforcera au lieu de penser à ta place.";
    }
    if (categorize(text) === "recherche" && scores.critique === 0) {
      return "Avant de réutiliser la réponse, demande-lui ses sources et ses limites. Une IA affirme avec le même aplomb quand elle se trompe.";
    }
    const lastThree = recentEvents.slice(-3);
    if (lastThree.length === 3 && lastThree.every((e) => e.scores.iteration === 0) && scores.iteration === 0) {
      return "Tu enchaînes les nouveaux sujets : creuse plutôt. Demande une critique ou une amélioration de la dernière réponse.";
    }
    return null;
  }

  // Banque de questions métacognitives, organisée par axes de raisonnement.
  // Le dialogue est infini par construction : les axes faibles d'abord, puis
  // connaissance/hypothèse, puis l'axe « approfondissement » qui boucle.
  // `label` sert au regroupement dans le prompt final compilé.
  const QUESTION_BANK = {
    intention: {
      label: "Ce que je veux obtenir",
      questions: [
        { key: "clarte", q: "Quel résultat précis attends-tu ? (livrable, format, longueur)" },
        { key: "intention-2", q: "À quoi verras-tu que la réponse est réussie ?" },
        { key: "intention-3", q: "Que feras-tu concrètement de la réponse une fois obtenue ?" },
        { key: "intention-4", q: "Quelle est la vraie question derrière ta question ?" },
      ],
    },
    connaissance: {
      label: "Ce que je sais déjà ou ai tenté",
      questions: [
        { key: "delegation", q: "Qu'as-tu déjà essayé ou pensé toi-même ? Décris ta piste : l'IA la renforcera au lieu de penser à ta place." },
        { key: "connaissance-2", q: "Que sais-tu déjà sur ce sujet, même approximativement ?" },
        { key: "connaissance-3", q: "Quelle partie pourrais-tu faire sans l'IA ?" },
        { key: "connaissance-4", q: "Où as-tu déjà cherché avant de demander ici ?" },
      ],
    },
    hypothese: {
      label: "Mon hypothèse",
      questions: [
        { key: "hypothese-1", q: "Quelle est TA réponse provisoire, même imparfaite ?" },
        { key: "hypothese-2", q: "Qu'est-ce qui te fait penser que c'est la bonne piste ?" },
        { key: "hypothese-3", q: "Quelle serait la réponse opposée à la tienne — et qu'est-ce qui la rendrait crédible ?" },
      ],
    },
    contexte: {
      label: "Mon contexte",
      questions: [
        { key: "contexte", q: "Quel est le contexte ? (qui es-tu, pour qui, avec quelles contraintes)" },
        { key: "contexte-2", q: "Quelles contraintes la réponse doit-elle absolument respecter ?" },
        { key: "contexte-3", q: "Qui utilisera le résultat, et qu'est-ce qui compte pour cette personne ?" },
      ],
    },
    critique: {
      label: "Comment je vérifierai",
      questions: [
        { key: "critique", q: "Comment vérifieras-tu la réponse ? Pense à demander sources, limites ou alternatives." },
        { key: "critique-2", q: "Quel serait le pire effet d'une réponse fausse ici ?" },
        { key: "critique-3", q: "Sur quoi l'IA risque-t-elle le plus de se tromper dans ce sujet ?" },
      ],
    },
    approfondissement: {
      label: "Ma réflexion",
      questions: [
        { key: "iteration", q: "En quoi ta demande a-t-elle évolué depuis le début de cette réflexion ?" },
        { key: "appro-2", q: "Qu'est-ce qui te ferait changer d'avis sur ce que tu viens de dire ?" },
        { key: "appro-3", q: "Si tu devais expliquer ton besoin à un enfant de 10 ans, tu dirais quoi ?" },
        { key: "appro-4", q: "Qu'est-ce qui te manque vraiment pour avancer seul ?" },
        { key: "appro-5", q: "Quelle question devrais-tu te poser que tu évites ?" },
        { key: "appro-6", q: "Quel serait ton plan en trois étapes si l'IA n'existait pas ?" },
      ],
    },
  };

  // Prochaine question du dialogue. Ne retourne jamais null : quand tout a été
  // posé, l'axe « approfondissement » recycle (sans reproposer la dernière).
  // Les templates de l'organisation écrasent les questions de même clé.
  function nextQuestion(state, templates = {}) {
    const { originalPrompt = "", scores, asked = [] } = state;
    const askedSet = new Set(asked);

    const weakAxes = [
      ["intention", scores.clarte],
      ["contexte", scores.contexte],
      ["critique", scores.critique],
    ]
      .filter(([, v]) => v < 13)
      .sort((a, b) => a[1] - b[1])
      .map(([axis]) => axis);

    const order = [];
    if (FULL_DELEGATION.test(originalPrompt)) order.push("connaissance");
    order.push(...weakAxes, "connaissance", "hypothese", "intention", "contexte", "critique", "approfondissement");
    const seen = new Set();
    const axes = order.filter((a) => !seen.has(a) && seen.add(a));

    const wrap = (axis, entry) => ({
      key: entry.key,
      axis,
      label: QUESTION_BANK[axis].label,
      question: templates[entry.key] || entry.q,
    });

    // Rotation entre les axes (un tour = un axe différent) pour un vrai
    // ping-pong varié, en commençant par les axes prioritaires.
    for (let i = 0; i < axes.length; i++) {
      const axis = axes[(asked.length + i) % axes.length];
      const entry = QUESTION_BANK[axis].questions.find((e) => !askedSet.has(e.key));
      if (entry) return wrap(axis, entry);
    }

    // Banque épuisée : on recycle l'approfondissement, jamais deux fois de suite la même.
    const pool = QUESTION_BANK.approfondissement.questions.filter((e) => e.key !== asked[asked.length - 1]);
    return wrap("approfondissement", pool[asked.length % pool.length]);
  }

  // Assemble le prompt final : la demande initiale + la réflexion construite
  // pendant le dialogue, regroupée par axe. Les réponses vides sont ignorées.
  function compilePrompt(originalPrompt, answers) {
    const filled = (answers || []).filter((a) => a.answer && a.answer.trim());
    if (!filled.length) return originalPrompt;
    const byLabel = new Map();
    for (const a of filled) {
      const label = a.label || "Ma réflexion";
      if (!byLabel.has(label)) byLabel.set(label, []);
      byLabel.get(label).push(a.answer.trim());
    }
    const lines = [];
    for (const [label, items] of byLabel) {
      for (const item of items) lines.push(`- ${label} : ${item}`);
    }
    return `${originalPrompt.trim()}\n\nMa réflexion préalable :\n${lines.join("\n")}`;
  }

  return { categorize, score, socraticSuggestion, nextQuestion, compilePrompt, wordCount };
})();
