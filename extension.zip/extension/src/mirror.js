// Miroir socratique — deux formes, toutes deux en Shadow DOM (styles isolés du site) :
//   show(message)  : toast non bloquant (suggestions légères).
//   showModal(...) : dialogue socratique ITÉRATIF — le prompt a été RETENU avant
//                    l'envoi. Une question à la fois, l'utilisateur répond, la
//                    suivante s'adapte, sans fin : seul l'utilisateur décide de
//                    sortir (« Envoyer au chat », demande initiale, ou Échap).
//                    L'aperçu du prompt final se construit sous ses yeux.

const CoachMirror = (() => {
  let toastHost = null;
  let modalHost = null;
  let hideTimer = null;

  const BASE_FONT = `-apple-system, "Segoe UI", sans-serif`;

  /* ---------- Toast non bloquant ---------- */

  function ensureToast() {
    if (toastHost && document.contains(toastHost)) return toastHost.shadowRoot;
    toastHost = document.createElement("div");
    toastHost.id = "coach-ia-toast";
    const shadow = toastHost.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        .panel { position: fixed; bottom: 96px; right: 24px; z-index: 2147483647;
          max-width: 340px; padding: 14px 16px; border-radius: 12px;
          background: #1e1b2e; color: #f4f2ff; border: 1px solid var(--accent, #6d5bd0);
          font: 14px/1.45 ${BASE_FONT}; box-shadow: 0 8px 24px rgba(0,0,0,.35);
          opacity: 0; transform: translateY(8px); transition: opacity .25s, transform .25s; }
        .panel.visible { opacity: 1; transform: translateY(0); }
        .title { display: flex; gap: 8px; font-weight: 600; margin-bottom: 6px; color: var(--accent-soft, #b9aaff); }
        .close { margin-left: auto; cursor: pointer; border: 0; background: none; color: #8f86b3; font-size: 16px; padding: 2px; }
        .useful { margin-top: 10px; cursor: pointer; border: 1px solid var(--accent, #6d5bd0); background: none; color: var(--accent-soft, #b9aaff); border-radius: 8px; padding: 4px 10px; font-size: 12px; }
      </style>
      <div class="panel" role="status">
        <div class="title"><span class="brand">🪞 Miroir socratique</span> <button class="close">✕</button></div>
        <div class="message"></div>
        <button class="useful">👍 Utile</button>
      </div>`;
    document.documentElement.appendChild(toastHost);
    shadow.querySelector(".close").addEventListener("click", () => hideToast("dismissed"));
    shadow.querySelector(".useful").addEventListener("click", () => {
      if (typeof CoachMirror.onFeedback === "function") CoachMirror.onFeedback("useful");
      hideToast("useful");
    });
    return shadow;
  }

  function show(message) {
    const shadow = ensureToast();
    shadow.querySelector(".message").textContent = message;
    const panel = shadow.querySelector(".panel");
    requestAnimationFrame(() => panel.classList.add("visible"));
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => hideToast("timeout"), 15000);
  }

  function hideToast(reason) {
    clearTimeout(hideTimer);
    if (!toastHost) return;
    toastHost.shadowRoot.querySelector(".panel").classList.remove("visible");
    if (typeof CoachMirror.onClose === "function") CoachMirror.onClose(reason);
  }

  /* ---------- Modale : dialogue socratique itératif ---------- */

  // opts: {
  //   promptText, scoreBefore, branding: {name, color},
  //   rescore(text) -> scores,
  //   compile(originalPrompt, answers) -> string,
  //   ask(state) -> Promise<{key, axis, label, question}>,   // state = {answers, asked}
  //   onSend(finalText, meta), onSendAnyway(meta), onCancel(meta)
  // }  meta = { rounds, answersCount }
  function showModal(opts) {
    closeModal();
    const accent = (opts.branding && opts.branding.color) || "#6d5bd0";

    const state = {
      answers: [], // {key, axis, label, question, answer}
      asked: [],
      current: null,
      previewFrozen: false, // édition manuelle de l'aperçu → on arrête de recompiler
    };

    modalHost = document.createElement("div");
    modalHost.id = "coach-ia-modal";
    const shadow = modalHost.attachShadow({ mode: "open" });
    shadow.innerHTML = `
      <style>
        :host { all: initial; }
        .overlay { position: fixed; inset: 0; z-index: 2147483647; background: rgba(10,8,18,.55);
          display: flex; align-items: center; justify-content: center; font: 14px/1.5 ${BASE_FONT}; }
        .modal { width: min(640px, 94vw); max-height: 90vh; display: flex; flex-direction: column;
          background: #1e1b2e; color: #f4f2ff; border: 1px solid ${accent}; border-radius: 16px;
          box-shadow: 0 16px 48px rgba(0,0,0,.5); overflow: hidden; }
        .head { display: flex; align-items: center; padding: 14px 18px 10px; }
        h1 { font-size: 15px; margin: 0; color: ${accent}; filter: brightness(1.4); }
        .closex { margin-left: auto; border: 0; background: none; color: #8f86b3; font-size: 16px; cursor: pointer; }
        .sub { padding: 0 18px 8px; color: #8f86b3; font-size: 12px; }
        .score { font-variant-numeric: tabular-nums; font-weight: 700; color: ${accent}; filter: brightness(1.3); }

        .thread { flex: 1; min-height: 60px; max-height: 32vh; overflow-y: auto; padding: 4px 18px; }
        .bubble { max-width: 85%; margin-bottom: 8px; padding: 8px 12px; border-radius: 12px; white-space: pre-wrap; }
        .bubble.coach { background: #2a2440; border: 1px solid #3a3355; border-bottom-left-radius: 4px; }
        .bubble.user { background: ${accent}; color: #fff; margin-left: auto; border-bottom-right-radius: 4px; opacity: .92; }
        .bubble.skip { background: none; border: 1px dashed #3a3355; color: #8f86b3; font-style: italic; }
        .thinking { color: #8f86b3; font-size: 12px; padding: 0 18px 6px; }

        .answer-zone { padding: 6px 18px 10px; border-top: 1px solid #2a2440; }
        .answer-row { display: flex; gap: 8px; align-items: flex-end; }
        textarea { box-sizing: border-box; background: #17141f; color: #f4f2ff; border: 1px solid #3a3355;
          border-radius: 10px; padding: 8px 10px; font: 13px/1.5 ${BASE_FONT}; resize: vertical; }
        textarea:focus { outline: none; border-color: ${accent}; }
        .answer { flex: 1; min-height: 40px; max-height: 100px; }
        .reply { padding: 8px 14px; border-radius: 9px; border: 1px solid ${accent}; background: ${accent};
          color: #fff; font-weight: 600; cursor: pointer; font-size: 13px; }
        .reply:hover { filter: brightness(1.15); }
        .skip-link { border: 0; background: none; color: #8f86b3; font-size: 11px; cursor: pointer;
          text-decoration: underline; padding: 4px 0 0; }
        .skip-link:hover { color: #f4f2ff; }

        .preview-zone { padding: 10px 18px 14px; border-top: 1px solid #2a2440; background: #191527; }
        .preview-head { display: flex; align-items: center; gap: 8px; font-size: 11px; color: #8f86b3;
          text-transform: uppercase; letter-spacing: .05em; margin-bottom: 6px; }
        .recompile { display: none; border: 0; background: none; color: ${accent}; font-size: 11px;
          cursor: pointer; text-decoration: underline; filter: brightness(1.3); }
        .preview-zone.frozen .recompile { display: inline; }
        .preview { width: 100%; min-height: 70px; max-height: 140px; }
        .buttons { display: flex; gap: 10px; margin-top: 10px; }
        .send { flex: 1; padding: 10px 14px; border-radius: 9px; border: 1px solid ${accent}; background: ${accent};
          color: #fff; font-weight: 600; cursor: pointer; font-size: 13px; }
        .send:hover { filter: brightness(1.15); }
        .anyway { padding: 10px 12px; border-radius: 9px; border: 1px solid #3a3355; background: none;
          color: #8f86b3; cursor: pointer; font-size: 12px; }
        .anyway:hover { color: #f4f2ff; }
      </style>
      <div class="overlay">
        <div class="modal" role="dialog" aria-modal="true">
          <div class="head"><h1></h1><button class="closex" title="Annuler (rien ne part, ton texte reste dans la zone de saisie)">✕</button></div>
          <div class="sub">Prompt retenu avant envoi — score initial <span class="score before"></span>/100.
            Réponds autant de fois que tu veux : c'est toi qui décides quand envoyer.</div>
          <div class="thread"></div>
          <div class="thinking" hidden>…</div>
          <div class="answer-zone">
            <div class="answer-row">
              <textarea class="answer" placeholder="Ta réponse… (Entrée pour valider, Shift+Entrée pour un saut de ligne)"></textarea>
              <button class="reply">Répondre</button>
            </div>
            <button class="skip-link">Passer cette question</button>
          </div>
          <div class="preview-zone">
            <div class="preview-head">
              <span>Prompt qui sera envoyé — score <span class="score after"></span>/100</span>
              <button class="recompile">recompiler depuis le dialogue</button>
            </div>
            <textarea class="preview" spellcheck="false"></textarea>
            <div class="buttons">
              <button class="send">🚀 Envoyer au chat (avec ma réflexion)</button>
              <button class="anyway">Envoyer ma demande initiale telle quelle</button>
            </div>
          </div>
        </div>
      </div>`;
    document.documentElement.appendChild(modalHost);

    const el = (sel) => shadow.querySelector(sel);
    el("h1").textContent = `🪞 ${(opts.branding && opts.branding.name) || "Coach IA"} — réfléchissons ensemble`;
    el(".before").textContent = opts.scoreBefore;

    const thread = el(".thread");
    const answerBox = el(".answer");
    const preview = el(".preview");

    function bubble(kind, text) {
      const b = document.createElement("div");
      b.className = `bubble ${kind}`;
      b.textContent = text;
      thread.appendChild(b);
      thread.scrollTop = thread.scrollHeight;
    }

    function updatePreview() {
      if (state.previewFrozen) return;
      preview.value = opts.compile(opts.promptText, state.answers);
      el(".after").textContent = opts.rescore(preview.value).total;
    }

    function meta() {
      return {
        rounds: state.asked.length,
        answersCount: state.answers.filter((a) => a.answer && a.answer.trim()).length,
      };
    }

    // Boucle infinie : demander la question suivante (jamais de fin imposée).
    async function askNext() {
      el(".thinking").hidden = false;
      let q;
      try {
        q = await opts.ask({ answers: state.answers, asked: state.asked });
      } finally {
        el(".thinking").hidden = true;
      }
      state.current = q;
      state.asked.push(q.key);
      bubble("coach", q.question);
      answerBox.focus();
    }

    function submitAnswer(text) {
      if (!state.current) return;
      const answer = text.trim();
      state.answers.push({ ...state.current, answer });
      bubble(answer ? "user" : "skip", answer || "(question passée)");
      answerBox.value = "";
      updatePreview();
      askNext();
    }

    el(".reply").addEventListener("click", () => submitAnswer(answerBox.value));
    el(".skip-link").addEventListener("click", () => submitAnswer(""));
    answerBox.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        submitAnswer(answerBox.value);
      }
    });

    // Édition manuelle de l'aperçu → gel de la recompilation automatique.
    preview.addEventListener("input", () => {
      state.previewFrozen = true;
      el(".preview-zone").classList.add("frozen");
      el(".after").textContent = opts.rescore(preview.value).total;
    });
    el(".recompile").addEventListener("click", () => {
      state.previewFrozen = false;
      el(".preview-zone").classList.remove("frozen");
      updatePreview();
    });

    el(".send").addEventListener("click", () => {
      const finalText = preview.value.trim();
      if (!finalText) return;
      const m = meta();
      closeModal();
      opts.onSend(finalText, m);
    });
    el(".anyway").addEventListener("click", () => {
      const m = meta();
      closeModal();
      opts.onSendAnyway(m);
    });
    el(".closex").addEventListener("click", () => {
      const m = meta();
      closeModal();
      if (opts.onCancel) opts.onCancel(m);
    });
    el(".overlay").addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        const m = meta();
        closeModal();
        if (opts.onCancel) opts.onCancel(m);
      }
      e.stopPropagation(); // la frappe dans la modale ne doit pas fuir vers la page
    });

    updatePreview();
    askNext();
  }

  function closeModal() {
    if (modalHost) {
      modalHost.remove();
      modalHost = null;
    }
  }

  return { show, hide: hideToast, showModal, closeModal, onFeedback: null, onClose: null };
})();
