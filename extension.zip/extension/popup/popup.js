// Mini-dashboard local : login, stats agrégées, réglages et export CSV.
// Les stats détaillées vivent dans le dashboard web ; ici, l'essentiel.

const DASHBOARD_URL = "http://localhost:3000"; // URL Vercel en production

/* ---------- Authentification & sync ---------- */

function showAuthState(session, profile, orgConfig, pendingCount) {
  const form = document.getElementById("auth-form");
  const connected = document.getElementById("auth-connected");
  if (session) {
    form.hidden = true;
    connected.hidden = false;
    document.getElementById("auth-user").textContent = session.email || "connecté";
    document.getElementById("auth-org").textContent =
      orgConfig && orgConfig.branding ? orgConfig.branding.name : "aucune organisation rattachée";
    document.getElementById("sync-status").textContent = pendingCount
      ? `${pendingCount} événement(s) en attente de synchronisation`
      : "Tout est synchronisé ✓";
    if (orgConfig && orgConfig.branding) {
      document.getElementById("brand-title").textContent = `🪞 ${orgConfig.branding.name}`;
      if (orgConfig.branding.color) {
        document.documentElement.style.setProperty("--accent-strong", orgConfig.branding.color);
      }
    }
  } else {
    form.hidden = false;
    connected.hidden = true;
  }
}

function authError(message) {
  const el = document.getElementById("auth-error");
  el.textContent = message;
  el.hidden = !message;
}

async function handleAuth(kind) {
  authError("");
  const email = document.getElementById("auth-email").value.trim();
  const password = document.getElementById("auth-password").value;
  if (!email || !password) return authError("Email et mot de passe requis.");
  try {
    const session = kind === "login" ? await CoachApi.login(email, password) : await CoachApi.signup(email, password);
    if (!session) return authError("Compte créé — confirme ton email puis connecte-toi.");
    chrome.runtime.sendMessage({ type: "sync-now" }, () => refreshAuthUi());
  } catch (e) {
    authError(e.message === "Invalid login credentials" ? "Identifiants invalides." : e.message);
  }
}

function refreshAuthUi() {
  chrome.storage.local.get(["session", "profile", "orgConfig", "events"], (data) => {
    const pending = (data.events || []).filter((e) => !e.synced).length;
    showAuthState(data.session, data.profile, data.orgConfig, pending);
  });
}

document.getElementById("auth-login").addEventListener("click", () => handleAuth("login"));
document.getElementById("auth-signup").addEventListener("click", () => handleAuth("signup"));
document.getElementById("auth-logout").addEventListener("click", async () => {
  await CoachApi.logout();
  refreshAuthUi();
});
document.getElementById("open-dashboard").addEventListener("click", () => {
  chrome.tabs.create({ url: DASHBOARD_URL });
});
refreshAuthUi();

/* ---------- Stats locales ---------- */

const RUBRICS = [
  ["clarte", "Clarté"],
  ["contexte", "Contexte"],
  ["iteration", "Itération"],
  ["critique", "Esprit critique"],
];

function avg(arr) {
  return arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;
}

function render(events) {
  document.getElementById("stat-count").textContent = events.length;

  const totals = events.map((e) => e.scores.total);
  document.getElementById("stat-score").textContent = events.length ? `${Math.round(avg(totals))}/100` : "–";

  // Progression : score moyen des 7 derniers jours vs les 7 précédents.
  const now = Date.now();
  const week = 7 * 24 * 3600 * 1000;
  const recent = events.filter((e) => now - Date.parse(e.ts) < week);
  const before = events.filter((e) => now - Date.parse(e.ts) >= week && now - Date.parse(e.ts) < 2 * week);
  const trendEl = document.getElementById("stat-trend");
  if (recent.length && before.length) {
    const delta = Math.round(avg(recent.map((e) => e.scores.total)) - avg(before.map((e) => e.scores.total)));
    trendEl.textContent = `${delta >= 0 ? "+" : ""}${delta}`;
  } else {
    trendEl.textContent = "–";
  }

  const shown = events.filter((e) => e.mirrorShown);
  const useful = shown.filter((e) => e.mirrorFeedback === "useful");
  document.getElementById("stat-mirror").textContent = shown.length ? `${Math.round((useful.length / shown.length) * 100)} %` : "–";

  const rubricsEl = document.getElementById("rubrics");
  rubricsEl.textContent = "";
  if (!events.length) {
    const p = document.createElement("p");
    p.className = "empty";
    p.textContent = "Aucun prompt capté pour l'instant. Utilise ChatGPT, je te suis. 🙂";
    rubricsEl.appendChild(p);
  } else {
    for (const [key, label] of RUBRICS) {
      const value = avg(events.map((e) => e.scores[key]));
      const rubric = document.createElement("div");
      rubric.className = "rubric";
      const row = document.createElement("div");
      row.className = "row";
      const name = document.createElement("span");
      name.textContent = label;
      const val = document.createElement("span");
      val.textContent = `${value.toFixed(1)}/25`;
      row.append(name, val);
      const bar = document.createElement("div");
      bar.className = "bar";
      const fill = document.createElement("div");
      fill.className = "fill";
      fill.style.width = `${(value / 25) * 100}%`;
      bar.appendChild(fill);
      rubric.append(row, bar);
      rubricsEl.appendChild(rubric);
    }
  }

  const byCategory = {};
  for (const e of events) byCategory[e.category] = (byCategory[e.category] || 0) + 1;
  const catEl = document.getElementById("categories");
  catEl.textContent = "";
  for (const [cat, count] of Object.entries(byCategory).sort((a, b) => b[1] - a[1])) {
    const li = document.createElement("li");
    const b = document.createElement("b");
    b.textContent = count;
    li.append(`${cat} `, b);
    catEl.appendChild(li);
  }
}

function toCsv(events) {
  const header = ["date", "site", "categorie", "mots", "clarte", "contexte", "iteration", "critique", "total", "intercepte", "issue", "score_avant", "score_apres", "tours", "reponses", "miroir_affiche", "miroir_feedback", "texte"];
  const escape = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const rows = events.map((e) =>
    [e.ts, e.site, e.category, e.words, e.scores.clarte, e.scores.contexte, e.scores.iteration, e.scores.critique, e.scores.total, e.intercepted ?? false, e.outcome ?? "", e.scoreBefore ?? "", e.scoreAfter ?? "", e.rounds ?? 0, e.answersCount ?? 0, e.mirrorShown, e.mirrorFeedback ?? "", e.text ?? ""].map(escape).join(";")
  );
  return [header.join(";"), ...rows].join("\n");
}

chrome.storage.local.get(["events", "settings", "health_chatgpt", "health_claude"], (data) => {
  const events = data.events || [];
  render(events);

  const settings = { captureMode: "metadata", interceptEnabled: true, threshold: 40, ...(data.settings || {}) };
  document.getElementById("setting-mirror").checked = settings.interceptEnabled;
  document.getElementById("setting-fulltext").checked = settings.captureMode === "full";
  document.getElementById("setting-threshold").value = settings.threshold;
  document.getElementById("threshold-value").textContent = settings.threshold;

  const broken = [
    ["ChatGPT", data.health_chatgpt],
    ["Claude", data.health_claude],
  ].filter(([, h]) => h && !h.healthy);
  if (broken.length) {
    const el = document.getElementById("health");
    el.textContent = `⚠️ Capture peut-être cassée sur : ${broken.map(([site]) => site).join(", ")} (UI modifiée)`;
    el.hidden = false;
  }
});

document.getElementById("setting-mirror").addEventListener("change", (e) => {
  chrome.storage.local.get("settings", (data) => {
    chrome.storage.local.set({ settings: { ...(data.settings || {}), interceptEnabled: e.target.checked } });
  });
});

document.getElementById("setting-threshold").addEventListener("input", (e) => {
  const threshold = Number(e.target.value);
  document.getElementById("threshold-value").textContent = threshold;
  chrome.storage.local.get("settings", (data) => {
    chrome.storage.local.set({ settings: { ...(data.settings || {}), threshold } });
  });
});

document.getElementById("setting-fulltext").addEventListener("change", (e) => {
  chrome.storage.local.get("settings", (data) => {
    chrome.storage.local.set({ settings: { ...(data.settings || {}), captureMode: e.target.checked ? "full" : "metadata" } });
  });
});

document.getElementById("export").addEventListener("click", () => {
  chrome.storage.local.get("events", (data) => {
    const blob = new Blob(["﻿" + toCsv(data.events || [])], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `coach-ia-export-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  });
});

document.getElementById("reset").addEventListener("click", () => {
  if (confirm("Effacer toutes les données locales ?")) {
    chrome.storage.local.remove(["events", "health_chatgpt"], () => render([]));
  }
});
